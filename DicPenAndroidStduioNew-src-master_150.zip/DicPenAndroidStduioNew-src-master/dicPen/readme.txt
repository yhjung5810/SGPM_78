

# 릴리즈 절차.
Build > Generate Signed APK

C:\dulee\SVN\nosleep\pjt\DicPen\KeyStore\MediaEver.jks

key store password : mediaever

Key alias : DicPen

key password : mediaever