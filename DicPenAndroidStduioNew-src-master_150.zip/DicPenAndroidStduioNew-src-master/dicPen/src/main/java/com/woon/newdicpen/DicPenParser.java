package com.woon.newdicpen;

import java.util.LinkedList;

/**
 * Created by dulee on 2017-05-14.
 */

public class DicPenParser {

    private static String TAG = "DicPenParser";

    public static String getFiveStr(String text, int pos){
        StringBuilder sb = new StringBuilder();
        int len = text.length();

        sb.append(text.charAt(pos));
        LinkedList<Character> pre = new LinkedList<Character>();
        LinkedList<Character> next = new LinkedList<Character>();

//        Log.d(TAG,"msg:" + text);
//        Log.d(TAG,"center:" + text.charAt(pos) + ",pos:" + pos);
        int i = 1;
        while(true){
            if( pos + i < len) {
                next.add(text.charAt(pos + i));
            }
            if( pos -i >= 0 ){
                pre.add(text.charAt(pos -i));
            }
            if( pos +i >= len && pos -i < 0 ) break;
            i++;
        }
        i = 0;
        while (true){
            if( i >= 4) break;
            if( !next.isEmpty()){
                char poll = next.poll();
                sb.append(poll);
                i++;
                if( i >= 4) break;
            }
            if( !pre.isEmpty()){
                char poll = pre.poll();
                sb.insert(0,poll);
                i++;
                if( i >= 4) break;
            }
            if( next.isEmpty() && pre.isEmpty()) break;
        }

        return sb.toString();
    }
    public static String parseResult2(String str, int slang, int wordMode, MainViewActivity.ImgMargin margin){
        if( DicPenUtil.isNullOrEmpty(str)) return "";
        String ss[] = str.split("\\r\\n|\\n|\\r");
        if( ss == null || ss.length == 0 ) return "";

        String text = ss[ss.length -1];

        if( DicPenUtil.isNullOrEmpty(text)) return "";

        if( wordMode == Const.TRANS_MODE_1_SENTENCE /*||
                slang == Const.SRC_LANG_2_Chinese ||
                slang == Const.SRC_LANG_1_Japanese */){
            char[] chars= {
                    '#','?', '!', '@', '#','$','%', '^', '&', '*', '(', ')', '-',
                    '_', '=', '+', '\\', '|', ']', '}', '{', '[', '\"', '"',':', ';', '>', '<', ',', '.', '~','`'
            };
            text = removeStartEndSpecialChar(text, chars);

//            if( Const.SRC_LANG_2_Chinese == slang || slang == Const.SRC_LANG_1_Japanese){
//                // 중심을 기준으로 4~5자만 취득함.
//                if( text.length() > 5 ){
////                    int removeLen = text.length() - 5;
////                    int s = removeLen /2;
////                    int e = s + 5;
////                    text = text.substring(s,e);
//
//                    int x= (text.length() * margin.imgWidth) / (margin.imgWidth - margin.leftMargin - margin.rightMargin)/2;
//                    int pos = x - (margin.leftMargin * text.length()) / (margin.imgWidth - margin.leftMargin - margin.rightMargin);
//                    while (true) {
//                        char ch = text.charAt(pos);
//                        if( ch == ' '){
//                            if(pos== 0 ) break;
//                            pos--;
//                            continue;
//                        }
//                        break;
//                    }
//                    text = getFiveStr(text, pos);
//                    //Log.d(TAG, "s=" + s + ",e=" + e + ",text=" + text);
//                }
//            }
            return text;
        }
        char[] chars= {
                '#','@', '$','%', '^', '&', '*', '(', ')', '-',
                '_', '=', '+', '\\', '|', ']', '}', '{', '[', '\"', '"',':', ';', '>', '<', ',', '.', '~','`'
        };
        text = removeStartEndSpecialChar(text, chars);

        if( DicPenUtil.isNullOrEmpty(text)) return "";
        //int centerPos = text.length() / 2;
        //int pos = (margin.imgWidth + margin.leftMargin - margin.rightMargin) / 2 ;
        int x= (text.length() * margin.imgWidth) / (margin.imgWidth - margin.leftMargin - margin.rightMargin)/2;
        int pos = x - (margin.leftMargin * text.length()) / (margin.imgWidth - margin.leftMargin - margin.rightMargin);
        //Log.d(TAG, "###### pos:" + pos + ",x:" + x + ",w:" + margin.imgWidth + ",leftMargin:" + margin.leftMargin + ",rightMargin:" + margin.rightMargin + ",textLen:" + text.length());
        while (true) {
            char ch = text.charAt(pos);
            if( ch == ' '){
                if(pos== 0 ) break;
                pos--;
                continue;
            }
            break;
        }

        text = getWord(text,pos);

        if( slang == Const.SRC_LANG_0_English && wordMode == Const.TRANS_MODE_0_WORD){
            text = removeStartEndToAsciiChar(text);
        }

        if( DicPenUtil.isNullOrEmpty(text)) return "";

        //Log.v(TAG, "slang:" + slang + ", text=" + text + ",len=" + text.length());



//        int len = text.length();
//
//        ss = text.split(" ");
//
//        int wordCnt = ss.length;

        return text;
    }

    private  static String getWord(String str, int centerPos){
        int start, end;
        StringBuilder sb = new StringBuilder();
        start = getWordStartIndex(str, centerPos);
        end = getWordEndIndex(str, centerPos);
        for(int i = start; i <= end; i++){
            sb.append(str.charAt(i));
        }
        return sb.toString();
    }
    private static int getWordStartIndex(String str, int centerPos){
        int index = centerPos;
        boolean first = true;
        while(true){
            char ch = str.charAt(index);
            if( index == 0 ) break;
            if( ch == ' ') break;
            if( first){
                first = false;
            }
            index --;
        }
        if(first) return index;
        char ch = str.charAt(index);
        if( ch == ' ') index++;
        return index;
    }

    private  static int getWordEndIndex(String str, int centerPos){
        int index = centerPos;
        boolean first = true;
        int lastIndex = str.length() -1;
        while(true){
            char ch = str.charAt(index);
            if( index == lastIndex ) break;
            if( ch == ' ') break;
            if( first){
                first = false;
            }
            index ++;
        }
        if(first) return index;
        char ch = str.charAt(index);
        if( ch == ' ') index--;
        return index;
    }

    private static boolean isWhiteChar(Character ch){
        if( ch == ' ') return true;
        if( ch == '\t') return true;
        return false;
    }

    private static boolean isInChars(Character ch, char[] chars){
        for(char c : chars){
            if( c == ch ) return true;
        }
        return false;
    }

    private static boolean isUnicodeSpecial(Character ch){
//        int unicode = Character.getNumericValue(ch);
//        if( unicode >= 0xE0000 && unicode <= 0x10FFFF ) return true;
//        if( unicode >= 0xFE50 && unicode <= 0x1D7FF ) return true;
//        if( unicode >= 0xFB00 && unicode <= 0xFE2F ) return true;

        return false;
    }

    private static String removeStartEndSpecialChar(String str, char [] chars){
        StringBuilder sb = new StringBuilder();
        int lastCharIndex = str.length() -1;
        while(true){
            char ch = str.charAt(lastCharIndex);
            if( isWhiteChar(ch) || isInChars(ch, chars)){
                if( lastCharIndex == 0 ) break;
                lastCharIndex--;
                continue;
            }
            break;
        }
        boolean trimmedLeft = false;
        for(int i = 0; i <= lastCharIndex; i++){
            char ch = str.charAt(i);
            if( isWhiteChar(ch) && !trimmedLeft){
                continue;
            }
            if( isInChars(ch, chars)){
                continue;
            }
            trimmedLeft = true;
            sb.append(ch);
        }

        return sb.toString();
    }

    private static boolean isAsciiChar(Character ch){
        if(  (ch >= 'A' && ch <= 'Z' ) ||
                ( ch >= 'a' && ch <= 'z' ) ){
            return true;
        }
        return false;
    }

    private static String removeStartEndToAsciiChar(String str){
        StringBuilder sb = new StringBuilder();
        int lastCharIndex = str.length() -1;
        while(true){
            char ch = str.charAt(lastCharIndex);
            if( isWhiteChar(ch) || !isAsciiChar(ch)){
                if( lastCharIndex == 0 ) break;
                lastCharIndex--;
                continue;
            }
            break;
        }
        boolean trimmedLeft = false;
        for(int i = 0; i <= lastCharIndex; i++){
            char ch = str.charAt(i);
            if( isWhiteChar(ch) && !trimmedLeft){
                continue;
            }
            if( !isAsciiChar(ch)){
                continue;
            }
            trimmedLeft = true;
            sb.append(ch);
        }
        return sb.toString();
    }

    private static String removeCharsAll(String str, char [] chars){
        StringBuilder sb = new StringBuilder();
        if( DicPenUtil.isNullOrEmpty(str)) return sb.toString();

        for(int i = 0; i < str.length(); i++){
            char ch = str.charAt(i);
            if( isInChars(ch, chars)) continue;;
            sb.append(ch);
        }

        return sb.toString();
    }

    private static String removeAllSpecialChars(String str){
        char[] chars= {
                '#','?', '!', '@', '#','$','%', '^', '&', '*', '(', ')', '-',
                '_', '=', '+', '\\', '|', ']', '}', '{', '[', '\"', '"',':', ';', '>', '<', ',', '.', '~','`'
        };

        StringBuilder sb = new StringBuilder();
        if( DicPenUtil.isNullOrEmpty(str)) return sb.toString();

        for(int i = 0; i < str.length(); i++){
            char ch = str.charAt(i);
            if( isInChars(ch, chars)) continue;
            if( isUnicodeSpecial(ch)) continue;
            sb.append(ch);
        }

        return sb.toString();
    }

//    public static String parseReult(String tempstr, int slang) {
//        String ricText = null;
//        StringBuilder sb = new StringBuilder("");
//        //int strindex = 0;
//        int chn = -1853568;//14989440;
//        //int jpnm = -1933183;//14909825;
//        String[] rictext = tempstr.split(" ");
//        String resultstr = null;
//        int sumlen = 0;
//        for (int i = 0; i < rictext.length; i++) {
//            if (rictext[0].length() > tempstr.length() / 2 && !(slang == Const.SRC_LANG_1_Japanese || slang == Const.SRC_LANG_2_Chinese)) {
//                resultstr = rictext[0];
//                break;
//            } else if (sumlen > tempstr.length() / 2 && !(slang == Const.SRC_LANG_1_Japanese || slang == Const.SRC_LANG_2_Chinese)) {
//                resultstr = rictext[i];
//                break;
//            } else if (!(slang == Const.SRC_LANG_0_English || slang == Const.SRC_LANG_3_Korean)) {
//                resultstr = tempstr;
//                break;
//            }
//            sumlen += rictext[i].length();
//        }
//
//
//        return resultstr;
//    }
}
