package com.woon.newdicpen;

import android.content.SharedPreferences;
import android.util.Log;

/**
 * Created by dulee on 2017-05-14.
 */

public class DicUrl {

    public static String getSrcLanguageStr(int slang) {
        String srcLang = "";
        switch (slang) {
            case Const.AUTO_LANG:
                srcLang = "AUTO";
                break;
            case Const.SRC_LANG_0_English:
                srcLang = "eng";
                break;
//            case Const.SRC_LANG_1_Japanese:
//                srcLang = "jpn";
//                break;
//            case Const.SRC_LANG_2_Chinese:
//                srcLang = "chi_sim";
//                break;
//            case Const.SRC_LANG_3_Korean:
//                srcLang = "kor";
//                break;
            case Const.SRC_LANG_4_French:
                srcLang = "fra";
                break;
            case Const.SRC_LANG_5_German:
                srcLang = "deu";
                break;
            case Const.SRC_LANG_6_Spanish:
                srcLang = "spa";
                break;
        }

        return srcLang;
    }

    public static String getUrl(SharedPreferences mPref, int slang, int tlang, String dicName, String encqry) {
        Log.e("getUrl","src = "+slang+", tar = "+tlang +", dic = "+dicName+", encqry = "+encqry);
        String bUrl = "";
        String kordb = "";
        switch (slang) {
            case Const.AUTO_LANG:
                switch (tlang) {
                    case Const.DEST_LANG_0_English:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#auto/ko/" + encqry;
                                break;
                            case Const.DIC_NAVER:
//                                bUrl = "http://endic.naver.com/search.nhn?sLn=kr&isOnlyViewEE=N&query=" + encqry;
//                                bUrl = "https://endic.naver.com/enkrEntry.nhn?sLn=kr&entryId=" + encqry;
//                                bUrl = "https://en.dict.naver.com/#/search?query="+encqry;
                                if(encqry != ""){
                                    bUrl = "https://en.dict.naver.com/#/search?query="+encqry;
                                }else{
                                    bUrl = "https://en.dict.naver.com/#/main";
                                }
                                //bUrl = https://learn.dict.naver.com/wordbook/enkodict/#/my/main
//                                "https://en.dict.naver.com/#/main"
                                break;
                        }
                        break;
                    case Const.DEST_LANG_1_Japanese:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#auto/ja/" + encqry;
                                break;
                            case Const.DIC_YAHOO://
                                bUrl = "http://dic.search.yahoo.co.jp/search?ei=UTF-8&p=" + encqry + "&stype=full&fr=dic";
                        }
                        break;
                    case Const.DEST_LANG_2_Chinese:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/?tl=zh#auto/zh-CN/" + encqry;
                                break;
                            case Const.DIC_ICIBA:
                                bUrl = "http://www.iciba.com/" + encqry;
                                break;
                        }
                        break;
                    case Const.DEST_LANG_3_Korean:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#auto/ko/" + encqry;
                                break;
                            case Const.DIC_NAVER:
                                //bUrl = "http://dic.naver.com/search.nhn?sLn=kr&isOnlyViewEE=N&query=" + encqry;
//                                bUrl = "http://m.endic.naver.com/search.nhn?sLn=Eng&searchOption=all&query=" + encqry;
                                if(encqry != ""){
                                    bUrl = "https://en.dict.naver.com/#/search?query="+encqry;
                                }else{
                                    bUrl = "https://en.dict.naver.com/#/main";
                                }
                                break;
                        }
                        break;
                    case Const.DEST_LANG_4_French:
                        bUrl = "https://translate.google.com/#auto/fr/" + encqry;
                        break;
                    case Const.DEST_LANG_5_German:
                        bUrl = "https://translate.google.com/#auto/de/" + encqry;
                        break;
                    case Const.DEST_LANG_6_Spanish:
                        bUrl = "https://translate.google.com/#auto/es/" + encqry;
                        break;
                }
                break;
            case Const.SRC_LANG_0_English:
                switch (tlang) {
                    case Const.DEST_LANG_0_English:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#en/ko/" + encqry;
                                break;
                            case Const.DIC_NAVER:
//                                bUrl = "http://endic.naver.com/search.nhn?sLn=kr&isOnlyViewEE=N&query=" + encqry;
//                                bUrl = "https://endic.naver.com/enkrEntry.nhn?sLn=kr&entryId=" + encqry;
//                                bUrl = "https://en.dict.naver.com/#/search?query="+encqry;
                                if(encqry != ""){
                                    bUrl = "https://en.dict.naver.com/#/search?query="+encqry;
                                }else{
                                    bUrl = "https://en.dict.naver.com/#/main";
                                }
                                break;
                        }
                        break;
                    case Const.DEST_LANG_1_Japanese:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#en/ja/" + encqry;
                                break;
                            case Const.DIC_YAHOO://
                                bUrl = "http://dic.search.yahoo.co.jp/search?ei=UTF-8&p=" + encqry + "&stype=full&fr=dic";
                        }
                        break;
                    case Const.DEST_LANG_2_Chinese:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#en/zh-CN/" + encqry;
                                break;
                            case Const.DIC_ICIBA:
                                bUrl = "http://www.iciba.com/" + encqry;
                                break;
                        }
                        break;
                    case Const.DEST_LANG_3_Korean:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#en/ko/" + encqry;
                                break;
                            case Const.DIC_NAVER:
                                //bUrl = "http://dic.naver.com/search.nhn?sLn=kr&isOnlyViewEE=N&query=" + encqry;
//                                bUrl = "http://m.endic.naver.com/search.nhn?sLn=Eng&searchOption=all&query=" + encqry;
                                if(encqry != ""){
                                    bUrl = "https://en.dict.naver.com/#/search?query="+encqry;
                                }else{
                                    bUrl = "https://en.dict.naver.com/#/main";
                                }
                                break;
                        }
                        break;
                    case Const.DEST_LANG_4_French:
                        bUrl = "https://translate.google.com/#en/fr/" + encqry;
                        break;
                    case Const.DEST_LANG_5_German:
                        bUrl = "https://translate.google.com/#en/de/" + encqry;
                        break;
                    case Const.DEST_LANG_6_Spanish:
                        bUrl = "https://translate.google.com/#en/es/" + encqry;
                        break;
                }
                break;
//            case Const.SRC_LANG_3_Korean:
//                switch (tlang) {
//                    case Const.DEST_LANG_0_English:
//                        switch (dicName) {
//                            case Const.DIC_GOOGLE:
//                                bUrl = "https://translate.google.com/#ko/en/" + encqry;
//                                break;
//                            case Const.DIC_NAVER:
//                                bUrl = "http://endic.naver.com/search.nhn?sLn=kr&isOnlyViewEE=N&query=" + encqry;
//                                break;
//                        }
//                        break;
//                    case Const.DEST_LANG_1_Japanese:
//                        switch (dicName) {
//                            case Const.DIC_GOOGLE:
//                                bUrl = "https://translate.google.com/#ko/ja/" + encqry;
//                                break;
//                            case Const.DIC_NAVER:
//                                bUrl = "http://jpdic.naver.com/search.nhn?range=all&q=" + encqry + "&sm=jpd_hty";
//                                break;
//                        }
//                        break;
//                    case Const.DEST_LANG_2_Chinese:
//                        switch (dicName) {
//                            case Const.DIC_GOOGLE:
//                                bUrl = "https://translate.google.com/#ko/zh-CN/" + encqry;
//                                break;
//                            case Const.DIC_NAVER:
//                                bUrl = "http://cndic.naver.com/search/all?q=" + encqry;
//                                break;
//                        }
//                        break;
//                }
//                break;
//            case Const.SRC_LANG_1_Japanese:
//                switch (tlang) {
//                    case Const.DEST_LANG_0_English:
//                        switch (dicName) {
//                            case Const.DIC_GOOGLE:
//                                bUrl = "https://translate.google.com/#ja/en/" + encqry;
//                                break;
//                            case Const.DIC_YAHOO://
//                                bUrl = "http://dic.search.yahoo.co.jp/search?ei=UTF-8&p=" + encqry + "&stype=full&fr=dic";
//                                break;
//                        }
//                        break;
//                    case Const.DEST_LANG_1_Japanese:
//                        switch (dicName) {
//                        }
//                        break;
//                    case Const.DEST_LANG_2_Chinese:
//                        switch (dicName) {
//                            case Const.DIC_GOOGLE:
//                                bUrl = "https://translate.google.com/#ja/zh-CN/" + encqry;
//                                break;
//                        }
//                        break;
//                    case Const.DEST_LANG_3_Korean:
//                        switch (dicName) {
//                            case Const.DIC_GOOGLE:
//                                bUrl = "https://translate.google.com/#ja/ko/" + encqry;
//                                break;
//                            case Const.DIC_NAVER:
//                                bUrl = "http://jpdic.naver.com/search.nhn?range=all&q=" + encqry + "&sm=jpd_hty";
//                                break;
//                        }
//                        break;
//                }
//                break;
//            case Const.SRC_LANG_2_Chinese:
//                switch (tlang) {
//                    case Const.DEST_LANG_0_English:
//                        switch (dicName) {
//                            case Const.DIC_GOOGLE:
//                                bUrl = "https://translate.google.com/#zh-CN/en/" + encqry;
//                                break;
//                            case Const.DIC_ICIBA:
//                                bUrl = "http://www.iciba.com/" + encqry;
//                                break;
//                        }
//                        break;
//                    case Const.DEST_LANG_1_Japanese:
//                        switch (dicName) {
//                            case Const.DIC_GOOGLE:
//                                bUrl = "https://translate.google.com/#zh-CN/ja/" + encqry;
//                                break;
//                        }
//                        break;
//                    case Const.DEST_LANG_2_Chinese:
//                        switch (dicName) {
//                        }
//                        break;
//                    case Const.DEST_LANG_3_Korean:
//                        switch (dicName) {
//                            case Const.DIC_GOOGLE:
//                                bUrl = "https://translate.google.com/#zh-CN/ko/" + encqry;
//                                break;
//                            case Const.DIC_NAVER:
//                                if (DicPenUtil.isNullOrEmpty(encqry))
//                                    bUrl = "http://m.cndic.naver.com/?sLn=ko";
//                                else
//                                    bUrl = "http://m.cndic.naver.com/search/all?q=" + encqry;
//                                    //bUrl = "http://cndic.naver.com/search/all?q=" + encqry;
//                                break;
//                        }
//                        break;
//                }
//                break;
            case Const.SRC_LANG_4_French:
                switch (tlang) {
                    case Const.DEST_LANG_0_English:
                        bUrl = "https://translate.google.com/#fr/en/" + encqry;
                        break;
                    case Const.DEST_LANG_1_Japanese:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/fr/ja/" + encqry;
                                break;
                            case Const.DIC_YAHOO://
                                bUrl = "http://dic.search.yahoo.co.jp/search?ei=UTF-8&p=" + encqry + "&stype=full&fr=dic";
                        }
                        break;
                    case Const.DEST_LANG_2_Chinese:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#fr/zh-CN/" + encqry;
                                break;
                            case Const.DIC_ICIBA:
                                bUrl = "http://www.iciba.com/" + encqry;
                                break;
                        }
                        break;
                    case Const.DEST_LANG_3_Korean:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#fr/ko/" + encqry;
                                break;
                            case Const.DIC_NAVER:
                                if(encqry != ""){
                                    bUrl = "https://dict.naver.com/frkodict/french/#/search?query=" + encqry;
                                }else{
                                    bUrl = "https://dict.naver.com/frkodict/french/#/main";
                                }
//                                bUrl = "http://dict.naver.com/frkodict/#/search?query=" + encqry;
                                break;
                        }
                        break;
                    case Const.DEST_LANG_4_French:
                        bUrl = "https://translate.google.com/#fr/fr/" + encqry;
                        break;
                    case Const.DEST_LANG_5_German:
                        bUrl = "https://translate.google.com/#fr/de/" + encqry;
                        break;
                    case Const.DEST_LANG_6_Spanish:
                        bUrl = "https://translate.google.com/#fr/es/" + encqry;
                        break;
                }
                break;
            case Const.SRC_LANG_5_German:
                switch (tlang) {
                    case Const.DEST_LANG_0_English:
                        bUrl = "https://translate.google.com/#de/en/" + encqry;
                        break;
                    case Const.DEST_LANG_1_Japanese:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#de/ja/" + encqry;
                                break;
                            case Const.DIC_YAHOO://
                                bUrl = "http://dic.search.yahoo.co.jp/search?ei=UTF-8&p=" + encqry + "&stype=full&fr=dic";
                        }
                        break;
                    case Const.DEST_LANG_2_Chinese:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#de/zh-CN/" + encqry;
                                break;
                            case Const.DIC_ICIBA:
                                bUrl = "http://www.iciba.com/" + encqry;
                                break;
                        }
                        break;
                    case Const.DEST_LANG_3_Korean:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#de/ko/" + encqry;
                                break;
                            case Const.DIC_NAVER:
                                if(encqry != ""){
                                    bUrl = "https://dict.naver.com/dekodict/deutsch/#/search?query=" + encqry;
                                }else{
                                    bUrl = "https://dict.naver.com/dekodict/deutsch/#/main";
                                }

//                                bUrl = "http://dict.naver.com/dekodict/#/search?query=" + encqry;
                                break;
                        }
                        break;
                    case Const.DEST_LANG_4_French:
                        bUrl = "https://translate.google.com/#de/fr/" + encqry;
                        break;
                    case Const.DEST_LANG_5_German:
                        bUrl = "https://translate.google.com/#de/de/" + encqry;
                        break;
                    case Const.DEST_LANG_6_Spanish:
                        bUrl = "https://translate.google.com/#de/es/" + encqry;
                        break;
                }
                break;
            case Const.SRC_LANG_6_Spanish:
                switch (tlang) {
                    case Const.DEST_LANG_0_English:
                        bUrl = "https://translate.google.com/#es/en/" + encqry;
                        break;
                    case Const.DEST_LANG_1_Japanese:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#es/ja/" + encqry;
                                break;
                            case Const.DIC_YAHOO://
                                bUrl = "http://dic.search.yahoo.co.jp/search?ei=UTF-8&p=" + encqry + "&stype=full&fr=dic";
                        }
                        break;
                    case Const.DEST_LANG_2_Chinese:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#es/zh-CN/" + encqry;
                                break;
                            case Const.DIC_ICIBA:
                                bUrl = "http://www.iciba.com/" + encqry;
                                break;
                        }
                        break;
                    case Const.DEST_LANG_3_Korean:
                        switch (dicName) {
                            case Const.DIC_GOOGLE:
                                bUrl = "https://translate.google.com/#es/ko/" + encqry;
                                break;
                            case Const.DIC_NAVER:
                                if(encqry != ""){
                                    bUrl = "https://dict.naver.com/eskodict/espanol/#/search?query=" + encqry;
                                }else{
                                    bUrl = "https://dict.naver.com/eskodict/espanol/#/main";
                                }
//                                bUrl = "http://dict.naver.com/eskodict/#/search?query=" + encqry;
                                break;
                        }
                        break;
                    case Const.DEST_LANG_4_French:
                        bUrl = "https://translate.google.com/#es/fr/" + encqry;
                        break;
                    case Const.DEST_LANG_5_German:
                        bUrl = "https://translate.google.com/#es/de/" + encqry;
                        break;
                    case Const.DEST_LANG_6_Spanish:
                        bUrl = "https://translate.google.com/#es/es/" + encqry;
                        break;
                }
                break;

        }

        return bUrl;
    }
}
