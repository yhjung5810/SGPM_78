package com.woon.newdicpen;

/**
 * Created by dulee on 2017-05-14.
 */
public class MyTaskParams {
    int ver;
    String field;
    String keyword;

    MyTaskParams(int ver, String field, String keyword) {
        this.ver = ver;
        this.field = field;
        this.keyword = keyword;
    }
}