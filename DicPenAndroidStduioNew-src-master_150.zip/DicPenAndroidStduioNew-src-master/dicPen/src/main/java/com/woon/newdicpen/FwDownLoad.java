package com.woon.newdicpen;

import android.os.AsyncTask;
import android.util.Log;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;

/**
 * Created by dulee on 2017-05-14.
 */
public class FwDownLoad extends AsyncTask<MyTaskParams, Void, ArrayList<String>> {


    private static String TAG = "DOWNLOAD";
    private MainViewActivity activity;
    private boolean update = false;
    ByteArrayOutputStream pmos = new ByteArrayOutputStream();
    ByteArrayOutputStream smos = new ByteArrayOutputStream();
    byte v;

    public FwDownLoad(MainViewActivity activity) {
        this.activity = activity;
    }

    public void setActivity(MainViewActivity activity) {
        this.activity = activity;
    }

    @Override
    protected ArrayList<String> doInBackground(MyTaskParams... params) {
        /*if(getVersion()>params[0].ver)
		{
			update=true;
			fwDownLoad(params[0].field,params[0].keyword);
		}
		else
		{
			update=false;
		}*/
        v = getVersion();

        //Log.v("PMOS",Integer.toString((int)v));
        fwDownLoad(params[0].field, params[0].keyword);
        return null;

    }

    @Override
    protected void onPostExecute(ArrayList<String> result) {
        MainViewActivity act = activity;
        // this.activity = null;
        if (act == null) {
            //Log.v("PMOS","act null");

        } else {

            Log.v("PMOS", Integer.toString(v) + "=" + Integer.toString(act.version));
            if (v > act.version) {
                act.DownDone(pmos.toByteArray(), true);
                act.version = v;
            } else {
                if (v != 0)
                    act.DownDone(pmos.toByteArray(), false);
            }
        }


    }

    public byte getVersion() {
        ByteArrayOutputStream ver = new ByteArrayOutputStream();
        String IPP = "http://jilee58.cafe24.com/update/ver.txt";
        byte[] v = null;
        try {
            Log.i(TAG, "FILE_URLLINK1 : File URL is " + IPP);
            URL url = new URL(IPP);
            //  Log.i("FILE_NAME", "File name is "+fileName);
            Log.i(TAG, "FILE_URLLINK2 : File URL is " + url);
            URLConnection connection = url.openConnection();
            connection.connect();
            // this will be useful so that you can show a typical 0-100% progress bar
            //int fileLength = connection.getContentLength();

            // download the file
            InputStream input = new BufferedInputStream(url.openStream());
            //  OutputStream output = new FileOutputStream(dir+"/"+fileName);


            byte data[] = new byte[1024];
            long total = 0;
            int count;

            while ((count = input.read(data)) != -1) {
                total += count;
                ver.write(data, 0, count);

            }

            // output.flush();
            // output.close();
            input.close();
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
        v = ver.toByteArray();
        int a1 = (int) v[0] - 48;
        int a2 = (int) v[1] - 48;
        byte r = (byte) (a1 * 10 + a2);

        return r;
    }

    public void fwDownLoad(String pstr, String sstr) {
        String IPP = "http://jilee58.cafe24.com/fw/Project.bin";

        try {
            Log.i( TAG, "FILE_URLLINK1 : File URL is " + IPP);
            URL url = new URL(IPP);
            //  Log.i("FILE_NAME", "File name is "+fileName);
            Log.i( TAG, "FILE_URLLINK2 : File URL is " + url);
            URLConnection connection = url.openConnection();
            connection.connect();
            // this will be useful so that you can show a typical 0-100% progress bar
            //int fileLength = connection.getContentLength();

            // download the file
            InputStream input = new BufferedInputStream(url.openStream());
            //  OutputStream output = new FileOutputStream(dir+"/"+fileName);
            pmos = new ByteArrayOutputStream();

            byte data[] = new byte[1024];
            long total = 0;
            int count;

            while ((count = input.read(data)) != -1) {
                total += count;
                pmos.write(data, 0, count);

            }

            // output.flush();
            // output.close();
            input.close();
        } catch (Exception e) {
            e.printStackTrace();
            Log.i(TAG, "ERROR ON DOWNLOADING FILES : ERROR IS" + e);
            MainViewActivity act = activity;
            // this.activity = null;

            Log.v("PMOS", "NULL");
            act.DownDone(null, update);

        }

    }
}