package com.woon.newdicpen;


import android.app.ActionBar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.TextView;

public class UserPreference extends Activity {
    public static String TAG = "UserPreference";
    Spinner spinnerSrcLang;
    Spinner spinnerDestLang;
    Spinner spinnerLangDB;
    Button btn;
    Context context;
    private RadioGroup radioBrightness;
    int wordmode;
    int bright;
    int slang = Const.SRC_LANG_0_English;
    int tlang = Const.DEST_LANG_3_Korean;
    boolean isBr = false;
    //int usrdb;
    //private String dicName = "google";
    RadioButton br;
    TextView batteryText;
    Spinner[] spinner = new Spinner[3];

    public void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.userpreference);
//        ActionBar actionBar = getActionBar();
//        actionBar.setBackgroundDrawable(getResources().getDrawable(R.drawable.blue));

        spinnerSrcLang = (Spinner) findViewById(R.id.spinnerSrcLang);
        spinnerDestLang = (Spinner) findViewById(R.id.spinnerDestLang);
        spinnerLangDB = (Spinner) findViewById(R.id.spinnerLangDB);
        spinner[0] = spinnerSrcLang;
        spinner[1] = spinnerDestLang;
        spinner[2] = spinnerLangDB;
        radioBrightness = (RadioGroup) findViewById(R.id.radioGroupBrightness);
        batteryText = (TextView) findViewById(R.id.battext);

        context = this;
        final RadioButton brHigh = findViewById(R.id.brHigh);
        final RadioButton brMidium = findViewById(R.id.brMedium);
        final RadioButton brLow = findViewById(R.id.brLow);
        brHigh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                if (b){
                brLow.setChecked(false);
                brMidium.setChecked(false);
                bright = Const.BR_MODE_2_HIGH;
                Log.e(TAG, "나오냐 111");
                commitBright(bright);
                Log.e(TAG, "나오냐 222");
//                }
            }
        });
        brMidium.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                if (b){
                brLow.setChecked(false);
                brHigh.setChecked(false);
                bright = Const.BR_MODE_1_MEDIUM;
                Log.e(TAG, "나오냐 333");
                commitBright(bright);
                Log.e(TAG, "나오냐 444");
//                }
            }
        });
        brLow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
//                if (b){
                brHigh.setChecked(false);
                brMidium.setChecked(false);
                bright = Const.BR_MODE_0_LOW;
                Log.e(TAG, "나오냐 555");
                commitBright(bright);
                Log.e(TAG, "나오냐 666");
//                }
            }
        });
//        addListenerOnButton();

        spinnerSrcLang.setOnItemSelectedListener(new OnItemSelectedListener() {
            protected Adapter initializedAdapter = null;

            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (initializedAdapter != parent.getAdapter()) {
                    initializedAdapter = parent.getAdapter();
                    return;
                }
                resetPreference();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
        spinnerDestLang.setOnItemSelectedListener(new OnItemSelectedListener() {
            protected Adapter initializedAdapter = null;

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                if (initializedAdapter != parent.getAdapter()) {
                    initializedAdapter = parent.getAdapter();
                    return;
                }
                resetPreference();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }


        });
        spinnerLangDB.setOnItemSelectedListener(new OnItemSelectedListener() {
            protected Adapter initializedAdapter = null;

            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int position, long id) {
                if (initializedAdapter != parent.getAdapter()) {
                    initializedAdapter = parent.getAdapter();
                    return;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

        setPreference();
    }

    private void commitBright(int index) {
//        if (isBr){
        SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("MyPref", 0);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt("brmode", index);
        Log.e(TAG, "원래 저장값 = " + sharedPref.getInt("brmode", 1) + ", index = " + index);
        editor.commit();
        Log.e(TAG, "바뀐 저장값 = " + sharedPref.getInt("brmode", 1));
//        }else{
//            isBr = true;
//        }
    }

    private void commitTarget(int index) {
//        if (isBr){
        SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("MyPref", 0);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt("tar", index);
        Log.e(TAG, "원래 저장값 = " + sharedPref.getInt("brmode", 1) + ", index = " + index);
        editor.commit();
        Log.e(TAG, "바뀐 저장값 = " + sharedPref.getInt("brmode", 1));
//        }else{
//            isBr = true;
//        }
    }
    private void commitSrc(int index) {
//        if (isBr){
        SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("MyPref", 0);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putInt("src", index);
        Log.e(TAG, "원래 저장값 = " + sharedPref.getInt("brmode", 1) + ", index = " + index);
        editor.commit();
        Log.e(TAG, "바뀐 저장값 = " + sharedPref.getInt("brmode", 1));
//        }else{
//            isBr = true;
//        }
    }

    private void resetPreference() {
        slang = spinnerSrcLang.getSelectedItemPosition();
        tlang = spinnerDestLang.getSelectedItemPosition();
        commitTarget(tlang);
        commitSrc(slang);
        Log.d(TAG, "src lang : " + slang + ", dest lang : " + tlang);

        String[] arraySpinner = DicPenUtil.getArraySpinner(slang, tlang);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.spin_item, arraySpinner);
        spinnerLangDB.setAdapter(adapter);

    }

    private void setPreference() {
        SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("MyPref", 0);
        wordmode = sharedPref.getInt("mode", Const.TRANS_MODE_0_WORD);    // word or sentence.
        bright = sharedPref.getInt("brmode", Const.BR_MODE_1_MEDIUM);    // 카메라 설정.(밝기)
        slang = sharedPref.getInt("src", Const.SRC_LANG_0_English);        // source language.
        tlang = sharedPref.getInt("tar", Const.DEST_LANG_3_Korean);        // target language.
        //usrdb = sharedPref.getInt("usr", 0);        // user database filename.
        String dicName = sharedPref.getString("dicName", Const.DIC_NAVER);
        batteryText.setText(MainViewActivity.batTitle);

        String[] arraySpinner = DicPenUtil.getArraySpinner(slang, tlang);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                R.layout.spin_item, arraySpinner);

        spinnerLangDB.setAdapter(adapter);

        spinnerSrcLang.setSelection(slang);
        spinnerDestLang.setSelection(tlang);

        spinnerLangDB.setSelection(DicPenUtil.getSpinnerIndex(spinnerLangDB, dicName));

        if (bright == Const.BR_MODE_0_LOW) {
            br = (RadioButton) findViewById(R.id.brLow);
        } else if (bright == Const.BR_MODE_1_MEDIUM) {
            br = (RadioButton) findViewById(R.id.brMedium);
        } else if (bright == Const.BR_MODE_2_HIGH) {
            br = (RadioButton) findViewById(R.id.brHigh);
        }
        if (br != null)
            br.setChecked(true);
//            commitBright(bright);
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        commitPref();
    }

    private void commitPref() {
        Intent intent = new Intent();
        setResult(Activity.RESULT_OK, intent);

        int srcIndex = spinnerSrcLang.getSelectedItemPosition();
        int tarIndex = spinnerDestLang.getSelectedItemPosition();
        int usrIndex = spinnerLangDB.getSelectedItemPosition();
        String dicName = spinnerLangDB.getSelectedItem().toString();
//                int modeId = radioTransMode.indexOfChild(findViewById(radioTransMode.getCheckedRadioButtonId()));
        int brId = radioBrightness.indexOfChild(findViewById(radioBrightness.getCheckedRadioButtonId()));
//        if ((/*srcIndex == tarIndex) || (srcIndex > 3 && tarIndex != 3) || (srcIndex != 3 &&*/ tarIndex != 3)) {
//            AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
//            builder1.setMessage("Selected language not supported!");
//            builder1.setCancelable(true);
//
//            builder1.setPositiveButton(
//                    "Yes",
//                    new DialogInterface.OnClickListener() {
//                        public void onClick(DialogInterface dialog, int id) {
//                            dialog.cancel();
//                        }
//                    });
//
//            AlertDialog alert11 = builder1.create();
//            alert11.show();
//
//        } else {
            //String linkdb = "";
            SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("MyPref", 0);

            SharedPreferences.Editor editor = sharedPref.edit();
            editor.putInt("src", srcIndex);
            editor.putInt("tar", tarIndex);
            //editor.putInt("usr", usrIndex);
            editor.putString("dicName", dicName);
//                    editor.putInt("mode", modeId);
            editor.putInt("brmode", bright);

            editor.commit();
//                    Log.v("PRESET0", Integer.toString(srcIndex))
            finishActivity(Activity.RESULT_OK);
//        }
    }

//    public void addListenerOnButton() {
//
//        btn = (Button) findViewById(R.id.confirm);
//
//        btn.setOnClickListener(new View.OnClickListener() {
//
//            public void onClick(View arg0) {
////                int srcIndex = spinnerSrcLang.getSelectedItemPosition();
//                int tarIndex = spinnerDestLang.getSelectedItemPosition();
//                int usrIndex = spinnerLangDB.getSelectedItemPosition();
//                String dicName = spinnerLangDB.getSelectedItem().toString();
////                int modeId = radioTransMode.indexOfChild(findViewById(radioTransMode.getCheckedRadioButtonId()));
//                int brId = radioBrightness.indexOfChild(findViewById(radioBrightness.getCheckedRadioButtonId()));
//                if ((/*srcIndex == tarIndex) || (srcIndex > 3 && tarIndex != 3) || (srcIndex != 3 &&*/ tarIndex != 3)) {
//                    AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
//                    builder1.setMessage("Selected language not supported!");
//                    builder1.setCancelable(true);
//
//                    builder1.setPositiveButton(
//                            "Yes",
//                            new DialogInterface.OnClickListener() {
//                                public void onClick(DialogInterface dialog, int id) {
//                                    dialog.cancel();
//                                }
//                            });
//
//                    AlertDialog alert11 = builder1.create();
//                    alert11.show();
//
//                } else {
//                    //String linkdb = "";
//                    SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("MyPref", 0);
//
//                    SharedPreferences.Editor editor = sharedPref.edit();
////                    editor.putInt("src", srcIndex);
//                    editor.putInt("tar", tarIndex);
//                    //editor.putInt("usr", usrIndex);
//                    editor.putString("dicName", dicName);
////                    editor.putInt("mode", modeId);
//                    editor.putInt("brmode", brId);
//
//                    editor.commit();
////                    Log.v("PRESET0", Integer.toString(srcIndex));
//
//                    setResult(Activity.RESULT_OK);
//                    finish();
//                }
//            }
//
//        });
//    }

    public void addListenerOnSpinnerItemSelection() {
        spinnerSrcLang.setOnItemSelectedListener(new CustomOnItemSelectedListener());
        spinnerDestLang.setOnItemSelectedListener(new CustomOnItemSelectedListener());
        spinnerLangDB.setOnItemSelectedListener(new CustomOnItemSelectedListener());
    }

}
