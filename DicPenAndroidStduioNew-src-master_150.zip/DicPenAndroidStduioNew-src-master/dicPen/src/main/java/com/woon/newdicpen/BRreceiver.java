package com.woon.newdicpen;

import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

public class BRreceiver extends BroadcastReceiver{
	@Override
	 
	public void onReceive(Context context, Intent intent) {
		 String action = intent.getAction();
		Log.d("taaa",intent.getAction());
		Toast.makeText(context, intent.getAction() , Toast.LENGTH_SHORT).show();
		 
          if(BluetoothDevice.ACTION_FOUND.equals(action)){
                 //BluetoothDevice device = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE);
                // mArrayAdapter.add(device.getName() + "\n" +device.getAddress());
        	  Toast.makeText(context,"action=="+ action , Toast.LENGTH_SHORT).show();
          }
     
	}

}
