package com.woon.newdicpen;

import android.graphics.Bitmap;
import android.util.Log;
import android.widget.Spinner;

/**
 * Created by dulee on 2017-05-14.
 */

public class DicPenUtil {
    private static String TAG = "DicPenUtil";

    public static int getSpinnerIndex(Spinner spinner, String myString)
    {
        int index = 0;
        for (int i=0;i<spinner.getCount();i++){
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(myString)){
                index = i;
                break;
            }
        }
        return index;
    }

    public static boolean isNullOrEmpty(String str){
        if(str == null || str.isEmpty()) return true;
        return false;
    }

    public static Bitmap processBitmap(Bitmap bitmap){
        //Log.d(TAG, "width = " + bitmap.getWidth() + ",height = " + bitmap.getHeight());

        Bitmap mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);

        int force_remove = 10;
        for(int y= 0; y < bitmap.getHeight(); y++){
            StringBuilder buf = new StringBuilder();
            int blackCnt = 0;
            int blackCntMax = 0;
            for(int x = 0; x < bitmap.getWidth(); x++){
                int pixel = bitmap.getPixel(x,y);
                buf.append(String.format("%04x ", pixel));
                int a = 0xff & (pixel >> 24);
                int r = 0xff & (pixel >> 16);
                int g = 0xff & (pixel >> 8);
                int b = 0xff & (pixel >> 0);

                if( r <128 || g < 128 || b < 128 ){
                    mutableBitmap.setPixel(x,y,0xff000000);
                    blackCnt++;
                    if( blackCnt > blackCntMax) blackCntMax = blackCnt;
                }else{
                    mutableBitmap.setPixel(x,y,0xffffffff);
                    blackCnt = 0;
                }

            }
            if( blackCntMax > 100 || y < force_remove){    // 블랙라인.
                for(int x = 0; x < bitmap.getWidth(); x++){
                    mutableBitmap.setPixel(x,y,0xffffffff);
                }
            }
            //Log.d(TAG, "row=" + y + " " + buf.toString());
        }
        //return bitmap;
        //Log.d(TAG, "end of processBitmap");
        return mutableBitmap;
    }

    public static Bitmap processBitmapRemoveUnderline(Bitmap bitmap){
        //Log.d(TAG, "width = " + bitmap.getWidth() + ",height = " + bitmap.getHeight());

        Bitmap mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);

        int h = bitmap.getHeight();
        int force_remove = 12;
        for(int y= 0; y < bitmap.getHeight(); y++){
            StringBuilder buf = new StringBuilder();
            int blackCnt = 0;
            int blackCntMax = 0;
            for(int x = 0; x < bitmap.getWidth(); x++){
                int pixel = bitmap.getPixel(x,y);
                buf.append(String.format("%04x ", pixel));
                int a = 0xff & (pixel >> 24);
                int r = 0xff & (pixel >> 16);
                int g = 0xff & (pixel >> 8);
                int b = 0xff & (pixel >> 0);

                if( r <128 || g < 128 || b < 128 ){
                    blackCnt++;
                    if( blackCnt > blackCntMax) blackCntMax = blackCnt;
                }else{
                    blackCnt = 0;
                }

            }
            if( blackCntMax > 100 || (h- y) < force_remove){    // 블랙라인.
                for(int x = 0; x < bitmap.getWidth(); x++){
                    mutableBitmap.setPixel(x,y,0xffffffff);
                }
            }
            //Log.d(TAG, "row=" + y + " " + buf.toString());
        }
        //return bitmap;
        //Log.d(TAG, "end of processBitmap");
        return mutableBitmap;
    }

    public static Bitmap processBitmapRemoveUnderline2(Bitmap bitmap){
        //Log.d(TAG, "width = " + bitmap.getWidth() + ",height = " + bitmap.getHeight());

        Bitmap mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);

        int h = bitmap.getHeight();
        int force_remove = 12;
        for(int y= h - force_remove; y < bitmap.getHeight(); y++){
            for(int x = 0; x < bitmap.getWidth(); x++){
                mutableBitmap.setPixel(x,y,0xffffffff);
            }
        }
        return mutableBitmap;
    }
    public static Bitmap processBitmap(Bitmap _bitmap, MainViewActivity.ImgMargin margin){

        Bitmap bitmap = processBitmapRemoveUnderline2(_bitmap);

        Log.d(TAG, "width = " + bitmap.getWidth() + ",height = " + bitmap.getHeight());
        margin.leftMargin = 0;
        margin.rightMargin = 0;
        int maxBlackCnt = 8;
        int blackCnt = 0;
        for(int x= 0; x < bitmap.getWidth(); x++){
            StringBuilder buf = new StringBuilder();
            blackCnt = 0;
            for(int y = 0; y < bitmap.getHeight(); y++){
                int pixel = bitmap.getPixel(x,y);
                int a = 0xff & (pixel >> 24);
                int r = 0xff & (pixel >> 16);
                int g = 0xff & (pixel >> 8);
                int b = 0xff & (pixel >> 0);

                if( r <128 || g < 128 || b < 128 ){
                    buf.append("0");
                    blackCnt++;
                }else{
                    buf.append("1");
                }
            }
            //Log.d(TAG, "COL LEFT : " + buf.toString());
            if (blackCnt > maxBlackCnt) {
                break;
            }
            margin.leftMargin++;
        }



        for(int x= bitmap.getWidth() -1; x >= 0; x--){
            StringBuilder buf = new StringBuilder();
            blackCnt = 0;
            for(int y = 0; y < bitmap.getHeight(); y++){
                int pixel = bitmap.getPixel(x,y);
                int a = 0xff & (pixel >> 24);
                int r = 0xff & (pixel >> 16);
                int g = 0xff & (pixel >> 8);
                int b = 0xff & (pixel >> 0);

                if( r <128 || g < 128 || b < 128 ){
                    buf.append("0");
                    blackCnt++;
                }else{
                    buf.append("1");
                }
            }
            //Log.d(TAG, "COL RIGHT : " + buf.toString());

            if (blackCnt > maxBlackCnt) {
                break;
            }
            margin.rightMargin++;
        }
        return bitmap;
    }

    public static String[] getArraySpinner(int slang, int tlang){
        String[] arraySpinner = new String[0];
        if (slang == Const.AUTO_LANG){
            if (tlang == Const.DEST_LANG_3_Korean){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_NAVER};
            }else if (tlang ==Const.DEST_LANG_1_Japanese){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_YAHOO};
            }else if (tlang == Const.DEST_LANG_2_Chinese){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_ICIBA};
            }else{
                arraySpinner = new String[]{Const.DIC_GOOGLE};
            }
        }else if (slang == Const.SRC_LANG_0_English){
            if (tlang == Const.DEST_LANG_3_Korean){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_NAVER};
            }else if (tlang ==Const.DEST_LANG_1_Japanese){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_YAHOO};
            }else if (tlang == Const.DEST_LANG_2_Chinese){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_ICIBA};
            }else{
                arraySpinner = new String[]{Const.DIC_GOOGLE};
            }
        }else if (slang == Const.SRC_LANG_4_French){
            if (tlang == Const.DEST_LANG_3_Korean){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_NAVER};
            }else if (tlang ==Const.DEST_LANG_1_Japanese){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_YAHOO};
            }else if (tlang == Const.DEST_LANG_2_Chinese){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_ICIBA};
            }else{
                arraySpinner = new String[]{Const.DIC_GOOGLE};
            }
        }else if (slang == Const.SRC_LANG_5_German){
            if (tlang == Const.DEST_LANG_3_Korean){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_NAVER};
            }else if (tlang ==Const.DEST_LANG_1_Japanese){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_YAHOO};
            }else if (tlang == Const.DEST_LANG_2_Chinese){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_ICIBA};
            }else{
                arraySpinner = new String[]{Const.DIC_GOOGLE};
            }
        }else if (slang == Const.SRC_LANG_6_Spanish){
            if (tlang == Const.DEST_LANG_3_Korean){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_NAVER};
            }else if (tlang ==Const.DEST_LANG_1_Japanese){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_YAHOO};
            }else if (tlang == Const.DEST_LANG_2_Chinese){
                arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_ICIBA};
            }else{
                arraySpinner = new String[]{Const.DIC_GOOGLE};
            }
        }
//        if (/*slang == Const.SRC_LANG_1_Japanese &&*/ tlang == Const.DEST_LANG_2_Chinese) {
//            arraySpinner = new String[]{Const.DIC_GOOGLE};
//        } /*else if (slang == Const.SRC_LANG_2_Chinese && tlang == Const.SRC_LANG_1_Japanese) {
//            arraySpinner = new String[]{ Const.DIC_GOOGLE};
//        } */else if ((/*slang == Const.SRC_LANG_1_Japanese || */tlang == Const.DEST_LANG_1_Japanese)
//                && !(/*slang == Const.SRC_LANG_3_Korean || */tlang ==  Const.DEST_LANG_3_Korean)) {
//            arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_YAHOO};
//        } else if ((/*slang == Const.SRC_LANG_2_Chinese ||*/ tlang == Const.DEST_LANG_2_Chinese)
//                && !(/*slang == Const.SRC_LANG_3_Korean ||*/ tlang == Const.DEST_LANG_3_Korean)) {
//            arraySpinner = new String[]{Const.DIC_GOOGLE, Const.DIC_ICIBA};
//        } else if (/*slang == Const.SRC_LANG_3_Korean ||*/ tlang == Const.DEST_LANG_3_Korean) {
//            arraySpinner = new String[]{Const.DIC_NAVER, Const.DIC_GOOGLE};
//        } else {
//            arraySpinner = new String[]{Const.DIC_GOOGLE};
//        }
        return arraySpinner;
    }
}
