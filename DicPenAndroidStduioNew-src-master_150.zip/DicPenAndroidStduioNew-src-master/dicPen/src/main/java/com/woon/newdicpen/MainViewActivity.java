/*
 * © 2010 ABBYY. All rights reserved.
 * ABBYY, FineReader, and ABBYY FineReader are either registered trademarks or trademarks of ABBYY Software
 * Ltd.
 */
package com.woon.newdicpen;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.os.PowerManager;
import android.preference.PreferenceManager;
import android.provider.MediaStore;
import android.text.Html;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.WindowManager.LayoutParams;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.google.firebase.ml.vision.text.FirebaseVisionText;
import com.google.firebase.ml.vision.text.FirebaseVisionTextRecognizer;
import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import androidx.annotation.NonNull;


/**
 * Main application's activity.
 */
@SuppressLint("NewApi")
public class MainViewActivity extends Activity {

    private FirebaseAnalytics mFirebaseAnalytics;

    private byte[] fwdata;
    private byte[] rcvd = new byte[6000];
    private int packetsize = 5120;
    private static final String TAG = "MainViewActivity";
    //    private TessBaseAPI baseAPI;
    private TextView stateText;
    private TextView debugText;
    private final Handler handler = new Handler();
    private byte[] w = new byte[2048];
    private String txtReceive;
    private String txtDebug = "";
    Boolean isConnected = false;
    private int count = 0;
    private int rcvCount = 0;
    private static int slang = -1;
    protected boolean _active = true;
    private static String IP = "1.234.36.250";
    private final static int PORT = 9000;
    private static String urlLink = "http://1.234.36.250/fwdata.dat";
    private WebView webView;
    public static String batTitle = "배터리 잔량 : ";
    public String[] selLang = {"AUTO", "ENG", "FRA", "GER", "SPA", "KR", "CN", "JP"}; // 영 0, 일 1, 중 2, 한 3, 프 4, 독 5, 스 6, 자동 7

    private static enum ImageSource {
        RESOURCES,
        GALLERY,
        CAMERA
    }

    public static final String KEY_IMAGE_URI = "com.abbyy.mobile.ocr4.sample.IMAGE_URI";
    private static final String KEY_IMAGE_SOURCE = "com.abbyy.mobile.ocr4.sample.IMAGE_SOURCE";

    private static final int DIALOG_ERROR_LOADING_IMAGE = 0;
    private static final int DIALOG_SELECT_IMAGE_SOURCE = 1;

    private static final int REQUEST_CODE_PICK_IMAGE = 2;
    private static final int PREFERENCE_SET = 3;

    //private static final String KEY_IS_RECOGNIZING = "com.abbyy.mobile.ocr4.IS_RECOGNIZING";
    //private static final String KEY_RECOGNITION_PROGRESS = "com.abbyy.mobile.ocr4.RECOGNITION_PROGRESS";


    private static final int REQUEST_CODE_RECOGNITION_FINISHED = 0;
    public static final int MESSAGE_UNLOCK = 10;
    public static final int MESSAGE_BT_CONNECT = 11;
    public static final int MESSAGE_DISCOVERY_FINISHED = 12;
    public static final int MESSAGE_CONNECT_FAIL = 13;
    public static final int FW_UPDATE = 14;
    public static final int DIALOG_FW_DOWNLOAD_FAIL = 16;
    public static final int DIALOG_LOW_BATT = 17;
    public static final int NOT_CONNECT = 18;
    public static final int NOT_PAIRING = 19;
    /**
     * Preview for recognized image.
     */
    private ImageView _imagePreview;
    /**
     * Button for showing recognized image source dialog.
     */
    private View _sourceButton;
    /**
     * Button for showing preferences Activity.
     */
    private View _preferencesButton;
    /**
     * Button for starting text recognition.
     */
    private View _recognizeTextButton;
    /**
     * Button for starting BCR recognition.
     */
    private View _recognizeBcrButton;
    /**
     * Button for starting barcode recognition.
     */
    private View _recognizeBarcodeButton;

    /**
     * Recognized image source.
     */
    private ImageSource _imageSource = ImageSource.RESOURCES;
    private String SDCardRoot;
    private Uri _imageUri;
    private Bitmap _image;
    private AsyncTask<Void, Void, Bitmap> _imageLoadTask;
    private BroadcastReceiver _progressReceiver;
    private BroadcastReceiver _prebuiltWordsInfoReceiver;
    private BroadcastReceiver _rotationTypeDetectionReceiver;

    private boolean _isRecognizing;
    private boolean downFinish = false;
    ;
    private ProgressDialog _progressDialog;
    private int _progress = 0;
    private Handler _progressHandler;

    /**
     * Calls counter for enableButtons/disableButtons methods. Buttons are enabled when _disableButtonsCounter
     * == 0.
     */
    private int _disableButtonsCounter = 0;
    ////bluetooth
    private BluetoothAdapter mBluetoothAdapter = null;
    // Member object for the chat services
    private BluetoothService mChatService = null;
    private String mConnectedDeviceName = null;
    private static final boolean D = true;

    // Message types sent from the BluetoothChatService Handler
    public static final int MESSAGE_STATE_CHANGE = 1;
    public static final int MESSAGE_READ = 2;
    public static final int MESSAGE_WRITE = 3;
    public static final int MESSAGE_DEVICE_NAME = 4;
    public static final int MESSAGE_TOAST = 5;
    public static int readbyte = 0;
    // Key names received from the BluetoothChatService Handler
    public static final String DEVICE_NAME = "device_name";
    public static final String TOAST = "toast";

    // Intent request codes
    private static final int REQUEST_CONNECT_DEVICE = 4;
    private static final int REQUEST_ENABLE_BT = 5;
    private static final int DIALOG_FW_DOWNLOAD = 15;

    private List<Byte> packet_array = new ArrayList<Byte>();
    ByteArrayOutputStream imgos = new ByteArrayOutputStream();
    private int retry = 0;
    private String lastAddr = null;
    private Context context;
    String bUrl = null;
    String btitle = "";
    //////////////
    Window window;
    private int wordmode = Const.TRANS_MODE_0_WORD;
    private int bright = Const.BR_MODE_0_LOW;
    int bat_level = 0;

    String db = "NAVER";
    String kordb = "";
    String jpndb = "";
    String chndb = "";
    Activity activity;
    private int connectcount = 0;
    private SharedPreferences mPref;
    private static final String DEFAULT__SEPARATOR = ";";
    private String _separator;
    //int usrdb = 0;
    private String dicName = Const.DIC_NAVER;
    int tlang;
    public byte version = 0x00;
    private byte rcnt = 0;
    private boolean mIsReceiverRegistered = false;
    //File appDir;

    private void printInformation() {
        Context ctx = getApplicationContext();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            File[] files = ctx.getExternalFilesDirs(null);
            for (File f : files) {
                Log.i(TAG, "FILE : " + f);
            }
        } else { // for kitkat and above
            File files = ctx.getExternalFilesDir(null);
            Log.i(TAG, "FILE : " + files);
        }
//        File[] files = ctx.getExternalFilesDirs(null);
    }


    @Override
    public void onCreate(final Bundle savedInstanceState) {
        Log.v(TAG, "onCreate()");
        super.onCreate(savedInstanceState);


        setContentView(R.layout.main_view);

        PermissionListener permissionlistener = new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                Toast.makeText(MainViewActivity.this, "Permission Granted", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onPermissionDenied(ArrayList<String> deniedPermissions) {
                Toast.makeText(MainViewActivity.this, "Permission Denied\n" + deniedPermissions.toString(), Toast.LENGTH_SHORT).show();
            }


        };

        TedPermission.with(this)
                .setPermissionListener(permissionlistener)
//                .setDeniedMessage("어플리케이션의 기능 작동을 위해서는 권한이 필요합니다.\n\nPlease turn on permissions at [Setting] > [Permission]")
                .setPermissions(Manifest.permission.WAKE_LOCK,
                        Manifest.permission.INTERNET,
                        Manifest.permission.BLUETOOTH,
                        Manifest.permission.BLUETOOTH_ADMIN,
                        Manifest.permission.DISABLE_KEYGUARD,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE,
                        Manifest.permission.READ_EXTERNAL_STORAGE,
                        Manifest.permission.ACCESS_COARSE_LOCATION)
                .check();

        printInformation();

//        datapath = getFilesDir()+ "/tesseract/";
//        Log.d(TAG,"datapath:" + datapath);

        // 테스트용.
//        checkFile(new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/tessdata/"));
//        checkFileObb(new File(datapath + "tessdata/"));

//        baseAPI = new TessBaseAPI();

        activity = (Activity) this;
        context = this;
        window = this.getWindow();
        SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("MyPref", 0);
        mPref = PreferenceManager.getDefaultSharedPreferences(this);
        lastAddr = sharedPref.getString("addr", null);
        // Get local Bluetooth adapter
        mBluetoothAdapter = BluetoothAdapter.getDefaultAdapter();

        // If the adapter is null, then Bluetooth is not supported
        if (mBluetoothAdapter == null) {
            Toast.makeText(this, "Bluetooth is not available",
                    Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        rcvd = new byte[packetsize + 20];

    }

    private String datapath = "";
//    private void copyFiles(String filename) {
//        try {
//            String filepath = datapath + "/tessdata/" + filename;
//            File datafile = new File(filepath);
//            if (datafile.exists()) {
//                if (datafile.length() > 1024 * 1024) {
//                    return;
//                }
//            }
//
//            //String infilename = "/storage/3564-6330/tessdata/" + filename;
//            String infilename = Environment.getExternalStorageDirectory().getAbsolutePath() + "/tessdata/" + filename;
//            Log.i(TAG, infilename);
//            File infile = new File(infilename);
//            if( !infile.exists()){
//                Log.i(TAG,"FILE NOT EXISTS : " + infile);
//                return;
//            }
//
//            InputStream instream = new FileInputStream(infile);
//            OutputStream outstream = new FileOutputStream(filepath);
//
//            //copy the file to the location specified by filepath
//            byte[] buffer = new byte[1024];
//            int read;
//            while ((read = instream.read(buffer)) != -1) {
//                outstream.write(buffer, 0, read);
//            }
//            outstream.flush();
//            outstream.close();
//            instream.close();
//
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//    }

//    private void checkFile(File dir) {
//        //directory does not exist, but we can successfully create it
//        if (!dir.exists()){
//            dir.mkdirs();
//        }
//        //The directory exists, but there is no data file in it
//        if(dir.exists()) {
//            copyFiles("kor.traineddata");
//            copyFiles("chi_sim.traineddata");
//            copyFiles("deu.traineddata");
//            copyFiles("eng.traineddata");
//            copyFiles("fra.traineddata");
//            copyFiles("jpn.traineddata");
//            copyFiles("kor.traineddata");
//            copyFiles("spa.traineddata");
//        }
//    }

//    private  void saveFileFromObb(ZipResourceFile expansionFile, String filename ) throws  IOException{
//        String filepath = datapath + "/tessdata/" + filename;
//        File datafile = new File(filepath);
//        if (datafile.exists()) {
//            if (datafile.length() > 1024 * 1024) {
//                return;
//            }
//        }
//        InputStream instream = expansionFile.getInputStream(filename);
//        OutputStream outstream = new FileOutputStream(filepath,false);
//
//        //copy the file to the location specified by filepath
//        byte[] buffer = new byte[1024];
//        int read;
//        while ((read = instream.read(buffer)) != -1) {
//            outstream.write(buffer, 0, read);
//        }
//        outstream.flush();
//        outstream.close();
//        instream.close();
//    }
//    private void checkFileObb(File dir){
//        if (!dir.exists()){
//            dir.mkdirs();
//        }
//
//        if( !dir.exists()) {
//            Log.w(TAG, "dir not exists : " + dir.getPath());
//            return;
//        }
//        // package 를 체크하고.. 없으면
//        try{
//            Log.i(TAG, "getExternalStorageDirectory : " +  Environment.getExternalStorageDirectory().getAbsolutePath());
//            Log.i(TAG, "getPackageName : " + getPackageName());
//
////            PackageInfo pInfo = null;
////            pInfo = getPackageManager().getPackageInfo(this.getPackageName(), 0);
//
////            int versionCode = pInfo.versionCode;
////            Log.i(TAG, "versionCode : " + pInfo.versionCode);
//            int versionCode = 13;
//
//            //String versionName = pInfo.versionName;
//
//            ZipResourceFile expansionFile = APKExpansionSupport.getAPKExpansionZipFile(getApplicationContext(), versionCode, 0);
//
//            saveFileFromObb(expansionFile, "kor.traineddata");
//            saveFileFromObb(expansionFile, "chi_sim.traineddata");
//            saveFileFromObb(expansionFile, "deu.traineddata");
//            saveFileFromObb(expansionFile, "eng.traineddata");
//            saveFileFromObb(expansionFile, "fra.traineddata");
//            saveFileFromObb(expansionFile, "jpn.traineddata");
//            saveFileFromObb(expansionFile, "kor.traineddata");
//            saveFileFromObb(expansionFile, "spa.traineddata");
//
//        }catch (Exception ex){
//            ex.printStackTrace();
//            Log.e(TAG, ex.getLocalizedMessage());
//
//            AlertDialog.Builder alert = new AlertDialog.Builder(MainViewActivity.this);
//            alert.setPositiveButton("OK", new DialogInterface.OnClickListener() {
//                @Override
//                public void onClick(DialogInterface dialog, int which) {
//                    dialog.dismiss();     //닫기
//                }
//            });
//            alert.setMessage("Reinstall DicPen Please !.");
//            alert.show();
//        }
//    }


    public void DownDone(byte[] pdata, boolean update) {
        // Toast message = Toast.makeText(getBaseContext(), "download  MIDI files("+Integer.toString(sdata.length) , Toast.LENGTH_SHORT);
        //    message.show();
		/*if(!update)
		{
			txtDebug+="No update version\r\n";
			debugText.setText(txtDebug);
			return;
		}*/
		/*if(pdata==null  || pdata.length==0 || !update)
		{
			Toast message = Toast.makeText(getBaseContext(), "this firmware is latest version" , Toast.LENGTH_SHORT);
	        message.show();
	        return;
		}
		else*/
        {

            //debugText.setVisibility(View.VISIBLE);
            // webView.setVisibility(View.GONE);
            //txtDebug+="Ready to update\r\n";
            //debugText.setText(txtDebug);
            try {
                fwdata = new byte[pdata.length];
                fwdata = pdata;
                byte[] data = new byte[1024];
                System.arraycopy(fwdata, 0, data, 0, 1024);

                //setStatus("UPDATING ......");e
                if (update) {
                    sendPacket((byte) 0x00, data, Cmd.VER);
                    showDialog(MainViewActivity.DIALOG_FW_DOWNLOAD);
                } else {
                    showDialog(MainViewActivity.DIALOG_FW_DOWNLOAD_FAIL);
                }

            } catch (Exception e) {
                e.printStackTrace();
            }

        }

    }

    private String textOrg;
    private String textPrcs;

    private void inspectFromBitmap(Bitmap bitmap) {

//        //bitmap = DicPenUtil.processBitmap(bitmap);
////
////        baseAPI.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO_OSD);
////        //baseAPI.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO);
////        //bitmap = Bitmap.createScaledBitmap(bitmap,5128,960,true);
////        baseAPI.setImage(bitmap);
////        textOrg = baseAPI.getUTF8Text();
////        baseAPI.clear();
////        //String text2 = DicPenParser.parseReult(text, slang);
////        textPrcs = DicPenParser.parseResult2(textOrg, slang, wordmode, margin);
////        //Log.d(TAG, "org:" + textOrg + ",process:" + textPrcs);
////        if( bitmap == null ) Log.i(TAG, "bitmap is null");
////        //Log.v(TAG, "slang=" + slang + ",wordmode=" + wordmode);

        FirebaseVisionImage image = FirebaseVisionImage.fromBitmap(bitmap);
        FirebaseVisionTextRecognizer detector = FirebaseVision.getInstance().getOnDeviceTextRecognizer();
        Task<FirebaseVisionText> result = detector.processImage(image)
                .addOnSuccessListener(new OnSuccessListener<FirebaseVisionText>() {
                    @Override
                    public void onSuccess(FirebaseVisionText firebaseVisionText) {
                        if (firebaseVisionText.getTextBlocks().size() > 0) {
                            String text = selectedText(firebaseVisionText);
                            text = StringReplace(text);
//                                    String text = texts.getBlocks().get(0).getText();
//                                    Toast.makeText(context, ""+text, Toast.LENGTH_SHORT).show();
                            textPrcs = text;
                            Log.e("여기봐라", text);

                            StringBuilder sb = new StringBuilder();
                            Log.e(TAG, "ORG  : " + textOrg);
                            Log.e(TAG, "PRCS : " + textPrcs);
                            Log.e(TAG, "text : " + text);
//        sb.append("[").append(textOrg).append("]").append("\n")
//                .append("[").append(textPrcs).append("]");

                            //Toast.makeText(this, text, Toast.LENGTH_LONG).show();
                            if (DicPenUtil.isNullOrEmpty(text)) {
                                sb.append("failed");
//                                        Toast.makeText(context, sb.toString(), Toast.LENGTH_SHORT).show();
                            }

                            if (!DicPenUtil.isNullOrEmpty(text)) {
                                LoadDic(text);
                            }

//                                    searchDic(texts.getBlocks().get(0).getText());
                        }
//                                processTextRecognitionResult(texts);
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        e.printStackTrace();
                    }
                });
//        FirebaseVisionTextDetector detector = FirebaseVision.getInstance()
//                .getVisionTextDetector();
//        detector.detectInImage(image)
//                .addOnSuccessListener(
//                        new OnSuccessListener<FirebaseVisionText>() {
//                            @Override
//                            public void onSuccess(FirebaseVisionText texts) {
//                                if(texts.getBlocks().size() > 0){
//                                    String text = selectedText(texts);
//                                    text = StringReplace(text);
////                                    String text = texts.getBlocks().get(0).getText();
////                                    Toast.makeText(context, ""+text, Toast.LENGTH_SHORT).show();
//                                    textPrcs = text;
//                                    Log.e("여기봐라", text);
//
//                                    StringBuilder sb = new StringBuilder();
//                                    Log.e(TAG, "ORG  : " + textOrg);
//                                    Log.e(TAG, "PRCS : " + textPrcs);
//                                    Log.e(TAG, "text : " + text);
////        sb.append("[").append(textOrg).append("]").append("\n")
////                .append("[").append(textPrcs).append("]");
//
//                                    //Toast.makeText(this, text, Toast.LENGTH_LONG).show();
//                                    if( DicPenUtil.isNullOrEmpty(text)){
//                                        sb.append("failed");
////                                        Toast.makeText(context, sb.toString(), Toast.LENGTH_SHORT).show();
//                                    }
//
//                                    if( !DicPenUtil.isNullOrEmpty(text)){
//                                        LoadDic(text);
//                                    }
//
////                                    searchDic(texts.getBlocks().get(0).getText());
//                                }
////                                processTextRecognitionResult(texts);
//                            }
//                        })
//                .addOnFailureListener(
//                        new OnFailureListener() {
//                            @Override
//                            public void onFailure(@NonNull Exception e) {
//                                // Task failed with an exception
//                                e.printStackTrace();
//                            }
//                        });
    }

    //특수문자 제거 하기
    public static String StringReplace(String str) {
        Log.e("여기봐요", str);
        if (slang == 0 || slang == 2 || slang == 3 || slang == 4) {
            return str;
        }
        String match = "[^\uAC00-\uD7A3xfe0-9a-zA-Z\\s]";
        str = str.replaceAll(match, " ");

        return str;
    }

    private String selectedText(FirebaseVisionText texts) {
        String result = "";
        int num;
        int distance = 1000;
        int width = 320, height = 80;
        ArrayList<FirebaseVisionText.TextBlock> array = new ArrayList();
        array.addAll(texts.getTextBlocks());
        if (array.size() > 0) {
            for (int i = 0; i < array.size(); i++) {
                for (int j = 0; j < array.get(i).getLines().size(); j++) {
                    Log.e("라인나옴", "" + array.get(i).getLines().get(j).getText());
                    for (int k = 0; k < array.get(i).getLines().get(j).getElements().size(); k++) {
                        Rect rect = array.get(i).getLines().get(j).getElements().get(k).getBoundingBox();
                        Log.e("단어나옴", "" + array.get(i).getLines().get(j).getElements().get(k).getText());
                        if (rect.top < height && rect.bottom > height && rect.left < width && rect.right > width) {
                            result = array.get(i).getLines().get(j).getElements().get(k).getText();
                            return result;
                        } else {
                            int min = resultDistance1(rect);
                            if (distance >= min) {
                                distance = min;
                                result = array.get(i).getLines().get(j).getElements().get(k).getText();
                            }
                        }
                    }
                }
            }
        }
        return result;
    }

    private int resultDistance1(Rect rect) {
        ArrayList<Integer> sort = new ArrayList<>();

        int result;
        sort.add(resultDistance2(rect.left, rect.top));
        sort.add(resultDistance2(rect.left, rect.bottom));
        sort.add(resultDistance2(rect.right, rect.top));
        sort.add(resultDistance2(rect.right, rect.bottom));
        sort.add(resultDistance2(rect.centerX(), rect.centerY()));
        Collections.sort(sort);
        Log.e(TAG, "minDistance = " + sort.get(0));
        result = sort.get(0);

        return result;
    }

    private int resultDistance2(int x, int y) {
        int width = 320, height = 80;
        if (x >= width) {
            x = x - width;
        } else {
            x = width - x;
        }
        if (y >= height) {
            y = y - height;
        } else {
            y = height - y;
        }
        return x + y;
    }

    private void searchDic(Bitmap bitmap) {
        StringBuilder sb = new StringBuilder();
        Log.d(TAG, "ORG  : " + textOrg);
        Log.d(TAG, "PRCS : " + textPrcs);
//        sb.append("[").append(textOrg).append("]").append("\n")
//                .append("[").append(textPrcs).append("]");

//        //Toast.makeText(this, text, Toast.LENGTH_LONG).show();
//        if (DicPenUtil.isNullOrEmpty(textPrcs)) {
//            sb.append("failed");
//            Toast.makeText(this, sb.toString(), Toast.LENGTH_LONG).show();
//        }
//
//        if (!DicPenUtil.isNullOrEmpty(textPrcs)) {
//            LoadDic(textPrcs);
//        }
    }

    private int tlangToChange(int tlang) {
        switch (tlang) {
            case 0:
                tlang = 1;
                break;
            case 1:
                tlang = 2;
                break;
            case 2:
                tlang = 3;
                break;
            case 3:
                tlang = 4;
                break;
            case 4:
                tlang = 5;
                break;
            case 5:
                tlang = 6;
                break;
            case 6:
                tlang = 7;
                break;
            default:

        }
        return tlang;
    }

    @SuppressLint("NewApi")
    private void getPreferencesData() {
        SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("MyPref", 0);
        wordmode = sharedPref.getInt("mode", Const.TRANS_MODE_0_WORD);
        slang = sharedPref.getInt("src", Const.SRC_LANG_0_English);
        tlang = sharedPref.getInt("tar", Const.DEST_LANG_3_Korean);
        //usrdb = sharedPref.getInt("usr", 0);
        dicName = sharedPref.getString("dicName", Const.DIC_NAVER);
        //String userlink = sharedPref.getString("userlink", null);
        bright = sharedPref.getInt("brmode", Const.BR_MODE_1_MEDIUM);
        String[] array = getResources().getStringArray(R.array.src_lang);

//        baseAPI.end();

        String srcLangStr = DicUrl.getSrcLanguageStr(slang);

        //baseAPI.init(appDir.getPath(), srcLangStr);
//        baseAPI.init(datapath, srcLangStr);
//
//        baseAPI.setPageSegMode(TessBaseAPI.PageSegMode.PSM_AUTO);

        if (wordmode == Const.TRANS_MODE_0_WORD) {

            String title = "[DicPen]" + selLang[slang] + "->" + selLang[tlang + 1] + "(WORD)";
            setTitle(Html.fromHtml("<small>" + title + "</small>"));

        } else if (wordmode == Const.TRANS_MODE_1_SENTENCE) {

            String title = "[DicPen]" + selLang[slang] + "->" + selLang[tlang + 1] + "(SEN)";
            setTitle(Html.fromHtml("<small>" + title + "</small>"));
        }
        String encqry = "";
        bUrl = DicUrl.getUrl(mPref, slang, tlang, dicName, encqry);

        if (webView != null) {
            Log.d(TAG, "getPreferencesData-load url : " + bUrl);
            webView.loadUrl(bUrl);
        }
        getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0000ff")));
        String[] baseText = stateText.getText().toString().split(" 배터리");
        stateText.setText(baseText[0] + " " + batTitle);
    }

    private int getArrayIndex(int array, String findIndex) {
        String[] arrayString = getResources().getStringArray(array);
        for (int e = 0; e < arrayString.length; e++) {
            if (arrayString[e].equals(findIndex))
                return e;
        }
        return -1;
    }

    private void doDiscovery() {

        if (mChatService != null) {
            if (mChatService.getState() == BluetoothService.STATE_CONNECTED)
                mBluetoothAdapter.cancelDiscovery();
        }
        // If we're already discovering, stop it
        if (mBluetoothAdapter.isDiscovering()) {
            mBluetoothAdapter.cancelDiscovery();
        }

        // Request discover from BluetoothAdapter
        //	mBluetoothAdapter.startDiscovery();
        //if (D)
        Log.d(TAG, "doDiscovery()");
        boolean conn = false;
        BluetoothAdapter mBtAdapter = BluetoothAdapter.getDefaultAdapter();
        Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices();
        Log.v("bt", "found2");
        // If there are paired devices, add each one to the ArrayAdapter
        if (pairedDevices.size() > 0) {
            //Log.v("bt","found3");
            for (BluetoothDevice device : pairedDevices) {
                switch (device.getBondState()) {

                    case BluetoothDevice.BOND_BONDING:
                        //	Toast.makeText(context,"BOND_BONDING" , Toast.LENGTH_SHORT).show();
                        Log.d("BlueToothTestActivity", "it is pairing");
                        break;
                    case BluetoothDevice.BOND_BONDED:
                        Log.d("BlueToothTestActivity", "finish");
                        // Toast.makeText(context,"BOND_BONDED" , Toast.LENGTH_SHORT).show();
                        if (device.getName().equals("HC-06") || device.getName().equals("HC06_t1")) {
                            conn = true;
                            if (connectcount > 2) {

                                showDialog(NOT_CONNECT);
                                break;
                            }


                            connectDevice(null, device.getAddress());
                            doTempWakeLock();
                            //	Activity activity = (Activity)context;
                            //   activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                            break;
                        }
                        break;
                    case BluetoothDevice.BOND_NONE:
                        Log.d("BlueToothTestActivity", "cancel");
                        //   Toast.makeText(context,"BOND_NONE" , Toast.LENGTH_SHORT).show();
                    default:
                        break;
                }

            }

        }

        if (!conn) {
            showDialog(NOT_PAIRING);
        }

    }

    private final BroadcastReceiver mReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            // Toast.makeText(context,"action=="+ action , Toast.LENGTH_SHORT).show();
            Log.d("found", "action==" + action);
            boolean conn = false;
            BluetoothAdapter mBtAdapter = BluetoothAdapter.getDefaultAdapter();
			/* if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.M) {
				 Log.v("bt","found1");
				  mBtAdapter.cancelDiscovery();
				 if (mChatService.getState() == BluetoothService.STATE_CONNECTED) return;
				 Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices();
				 Log.v("bt","found2");
					// If there are paired devices, add each one to the ArrayAdapter
					 if(pairedDevices.size() > 0) {
						 //Log.v("bt","found3");
						for (BluetoothDevice device : pairedDevices) {
							switch (device.getBondState()) {

                           case BluetoothDevice.BOND_BONDING:
                           //	Toast.makeText(context,"BOND_BONDING" , Toast.LENGTH_SHORT).show();
                                   Log.d("BlueToothTestActivity", "it is pairing");
                                   break;
                           case BluetoothDevice.BOND_BONDED:
                                   Log.d("BlueToothTestActivity", "finish");
                                  // Toast.makeText(context,"BOND_BONDED" , Toast.LENGTH_SHORT).show();
                                   if(device.getName().equals("HC-06") || device.getName().equals("HC06_t1"))
   								{
                                	   conn=true;
                                   	if(connectcount>2)
                                   	{

                                   		showDialog(NOT_CONNECT);
                                   		break;
                                   	}

                                   	mBtAdapter.cancelDiscovery();
   									connectDevice(null,device.getAddress());
   									doTempWakeLock();
   								//	Activity activity = (Activity)context;
   							     //   activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
   							        break;
   								}
                                   break;
                           case BluetoothDevice.BOND_NONE:
                                   Log.d("BlueToothTestActivity", "cancel");
                                //   Toast.makeText(context,"BOND_NONE" , Toast.LENGTH_SHORT).show();
                           default:
                                   break;
							}

						}

					}

					 if (!conn)
					 {
						 doDiscovery();
					 }
			}
			 else*/
            if (BluetoothDevice.ACTION_FOUND.equals(action)) {


                Log.v("bt", "found1");
                mBtAdapter.cancelDiscovery();
                if (mChatService.getState() == BluetoothService.STATE_CONNECTED) return;
                Set<BluetoothDevice> pairedDevices = mBtAdapter.getBondedDevices();
                Log.v("bt", "found2");
                // If there are paired devices, add each one to the ArrayAdapter
                if (pairedDevices.size() > 0) {
                    //Log.v("bt","found3");
                    for (BluetoothDevice device : pairedDevices) {
                        switch (device.getBondState()) {

                            case BluetoothDevice.BOND_BONDING:
                                //	Toast.makeText(context,"BOND_BONDING" , Toast.LENGTH_SHORT).show();
                                Log.d("BlueToothTestActivity", "it is pairing");
                                break;
                            case BluetoothDevice.BOND_BONDED:
                                Log.d("BlueToothTestActivity", "finish");
                                // Toast.makeText(context,"BOND_BONDED" , Toast.LENGTH_SHORT).show();
                                if (device.getName().equals("HC-06") || device.getName().equals("HC06_t1")) {
                                    conn = true;
                                    if (connectcount > 2) {

                                        showDialog(NOT_CONNECT);
                                        break;
                                    }

                                    mBtAdapter.cancelDiscovery();
                                    connectDevice(null, device.getAddress());
                                    doTempWakeLock();
                                    //	Activity activity = (Activity)context;
                                    //   activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                                    break;
                                }
                                break;
                            case BluetoothDevice.BOND_NONE:
                                Log.d("BlueToothTestActivity", "cancel");
                                //   Toast.makeText(context,"BOND_NONE" , Toast.LENGTH_SHORT).show();
                            default:
                                break;
                        }

                    }

                }

                if (!conn) {
                    doDiscovery();
                }


            }
            // When discovery is finished, change the Activity title
            else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED
                    .equals(action)) {
                mHandler.obtainMessage(MainViewActivity.MESSAGE_DISCOVERY_FINISHED, 0, -1)
                        .sendToTarget();

            }
        }

    };

    private void doTempWakeLock() {
        PowerManager TempPowerManager = (PowerManager) getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock TempWakeLock = TempPowerManager.newWakeLock(
                PowerManager.FULL_WAKE_LOCK |
                        PowerManager.ACQUIRE_CAUSES_WAKEUP |
                        PowerManager.ON_AFTER_RELEASE, "TempWakeLock");
        TempWakeLock.acquire();

        // do the work that needs the visible display...
        mHandler.obtainMessage(MainViewActivity.MESSAGE_UNLOCK, 0, -1)
                .sendToTarget();

        // Release the newest wakelock and fall back to the old one
        TempWakeLock.release();
    }

    private void unpairDevice(BluetoothDevice device) {
        try {
            Method method = device.getClass().getMethod("removeBond", (Class[]) null);
            method.invoke(device, (Object[]) null);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String byteArrayToHex(byte[] rcvd2) {
        StringBuilder sb = new StringBuilder(rcvd2.length * 2);
        for (byte b : rcvd2)
            //  sb.append(String.format("%d-", b ));
            sb.append(String.format("%02x ", b & 0xff));
        return sb.toString();
    }

    public int[] bytearray2intarray(byte[] barray) {
        int[] iarray = new int[barray.length];
        int i = 0;
        for (byte b : barray)
            iarray[i++] = b & 0xff;
        return iarray;
    }

    public int bytearray2int(byte[] barray) {
        if (barray.length < 3) return 0;
        int iarray = 0;
        iarray += (int) barray[0] << 16;
        iarray += (int) barray[1] << 8;
        iarray += (int) barray[2] << 0;


        return iarray;
    }

    private void processRecieve(byte[] read, int rbyte) {
        byte[] inb = new byte[rbyte];
        if (rcvCount == 0) {

            System.arraycopy(read, 0, inb, 0, rbyte);
            rcvCount = rbyte;
        } else {
            System.arraycopy(inb, 0, rcvd, rcvCount, rbyte);
            rcvCount += rbyte;

        }

        if (rcvCount > packetsize + 5) {
            sendACK(2, rcnt);

        } else if (rcvCount == packetsize + 5) {

            sendACK(1, rcnt);
        } else if (rcvCount == 5) {

        }

    }

    private void processPacket(byte[] read, int rbyte) throws UnsupportedEncodingException {
        byte p_no = 0x00;
        byte[] inb = new byte[rbyte];
        byte[] rcv = new byte[10];
        System.arraycopy(read, 0, inb, 0, rbyte);

        //Log.v("IN_PACKET", "SUM=" + Integer.toString(rcvCount + rbyte) + ")" + "IN=(" + Integer.toString(rbyte) + ")" + byteArrayToHex(inb));

        //	   txtDebug += "rcv<====("+"SUM="+Integer.toString(rcvCount+rbyte)+")"+"IN=("+Integer.toString(rbyte)+")" +byteArrayToHex(rcv) + "\r\n";

        //		debugText.setText(txtDebug);

        if (rcvCount == 0) {
            //sendACK(6,rcnt);

            debugText.setText(txtDebug);
            byte[] inbyte = new byte[4];
            System.arraycopy(read, 0, inbyte, 0, 4);
            // Log.e("INBYTE",byteArrayToHex(inbyte) );
            for (int i = 0; i < rbyte; i++) {

                if (rbyte == 1 && inb[0] == 0x02) {
                    System.arraycopy(inb, 0, rcvd, 0, 1);
                    rcvCount = 1;


                    if (rcvCount > 0) return;

                } else if (rbyte == 3 && inb[0] == 0x02) {

                    System.arraycopy(inb, 0, rcvd, 0, 3);
                    rcvCount = 3;
                    ///  txtDebug += "rcv00====>("+Integer.toString(rcvCount)+")" +byteArrayToHex(inb) + "\r\n";

                    //debugText.setText(txtDebug);
                    if (rcvCount > 0) return;

                }

                switch (inb[i]) {
                    case 0x02:
                        //Log.v("COUNT",Integer.toString(i)+"=length"+Integer.toString(inb.length));
                        if (i + 1 >= inb.length) {
                            System.arraycopy(inb, 0, rcvd, 0, 1);
                            rcvCount = inb.length;
                            return;
                        }
                        switch (inb[i + 1]) {
                            case 0x41://'A'

                                System.arraycopy(inb, i, rcvd, 0, rbyte - i);
                                rcvCount = rbyte - i;
                                //   txtDebug += "rcv1====>("+Integer.toString(rcvCount)+")" +byteArrayToHex(inb) + "\r\n";

                                //	debugText.setText(txtDebug);
                                if (rcvCount >= packetsize + 5) {
                                    PrepareImage();
                                } else return;
                                break;
                            case 0x46://'F'download response
                                if (inb.length < 5) {
                                    System.arraycopy(inb, 0, rcvd, 0, inb.length);
                                    rcvCount = inb.length;
                                    return;
                                }


                                if ((inb[2] & 0x80) == 0x80) {
                                    if (fwdata == null) return;
                                    _progress = fwdata.length;
                                    _progressDialog.setProgress(_progress + 1);
                                    switch (inb[3]) {
                                        case 0x15://NAK
                                            retry++;
                                            if (retry > 2) {
                                                Log.v("NAK", Integer.toString(retry));
                                                downloadComplete(false);
                                                return;
                                            }
                                            break;
                                        case 0x05://NEOT
                                            downloadComplete(false);
                                            return;
                                        case 0x04://EOT
                                            downloadComplete(true);


                                            return;
                                    }
                                } else {
                                    _progress = (int) inb[2];
                                    _progressDialog.setProgress(_progress + 1);
                                    Log.v("DOWNLOAD", Integer.toString(_progress));
                                }

                                if (inb[3] == Cmd.ACK) {
                                    p_no = ++inb[2];
                                    retry = 0;
                                } else if (inb[3] == Cmd.NAK) {
                                    retry++;
                                    if (retry > 2) {
                                        Log.v("NAK", Integer.toString(retry));
                                        downloadComplete(false);
                                        return;
                                    }
                                    p_no = inb[2];
                                }


                                int start = p_no * 1024;
                                byte[] data = new byte[1024];

                                if ((fwdata.length - p_no * 1024) < 1024) {

                                    System.arraycopy(fwdata, start, data, 0, fwdata.length - p_no * 1024);
                                    p_no = (byte) (p_no | 0x80);
                                    downFinish = true;
                                } else {
                                    Log.v("OVER1", Integer.toString(p_no * 1024));

                                    System.arraycopy(fwdata, start, data, 0, 1024);
                                }

                                sendPacket(p_no, data, Cmd.VER);
                                return;

                            case 0x45://'E'
                                if (inb.length < 5) {
                                    System.arraycopy(inb, 0, rcvd, 0, inb.length);
                                    rcvCount = inb.length;
                                    return;
                                }

                                if (inb[3] == 0x7E) {
                                    downFinish = false;
                                    Log.v("DOWNLOAD", "START");
                                    //	setStatus("UPDATE-SERVER CONNECTION FAIL");
                                    version = inb[2];
                                    Log.v("DOWNLOAD", "START" + Integer.toString(version));
                                    MyTaskParams params = new MyTaskParams(inb[2], null, null);
                                    FwDownLoad myTask = new FwDownLoad((MainViewActivity) activity);
                                    myTask.setActivity((MainViewActivity) activity);
                                    myTask.execute(params);
                                    //  mode=FWD_MODE;
                                    //  sendData(0);
                                    rcvCount = 0;

                                    return;
                                }

                                break;
                            case 0x43://'C'
                                if (inb.length < 4) {
                                    mChatService.start();
                                    Log.v("SLEEP", " FORCE OK");
                                    try {
                                        Thread.sleep(2000);
                                    } catch (InterruptedException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                                    }
                                    if (!mBluetoothAdapter.isDiscovering())
                                        doDiscovery();
                                    rcvCount = 0;

                                    return;
                                }
                                if (inb[i + 2] == 0xFE && inb[i + 3] == 0x1F) {
                                    mChatService.start();
                                    Log.v("SLEEP", "OK");
                                    try {
                                        Thread.sleep(2000);
                                    } catch (InterruptedException e) {
                                        // TODO Auto-generated catch block
                                        e.printStackTrace();
                                    }
                                    if (!mBluetoothAdapter.isDiscovering())
                                        doDiscovery();
                                    rcvCount = 0;

                                    return;
                                }

                                break;
                        }
                        break;
                }
                // if(rcvCount>2)
                // break;
            }


            if (rcvCount >= packetsize + 5) {


                PrepareImage();
            }
        } else {
            if (rcvCount + rbyte > packetsize + 5) {
                rbyte = packetsize + 5 - rcvCount;
                System.arraycopy(inb, 0, rcvd, rcvCount, rbyte);
                //Log.e("LAST",byteArrayToHex(inb) );

                // txtDebug += "ERROR====>("+Integer.toString(rcvCount)+")"+Integer.toString(rbyte)+")" +byteArrayToHex(rcvd) + "\r\n";

                //debugText.setText(txtDebug);
                if (retry == 2) {
                    sendACK(1, rcnt);

                    txtDebug += "ERR IGNORE====>\r\n";
                    debugText.setText(txtDebug);
                    PrepareImage();
                } else {


                    txtDebug += "RETRY====>\r\n";
                    debugText.setText(txtDebug);
                    if ((rcvd[2] & 0x80) == 0x80) {
                        PrepareImage();
                    } else {
                        sendACK(1, rcnt);//sendACK(2, rcnt);
                        Log.d("NAK", "1");
                        rcvd = new byte[packetsize + 5];
                        rcvCount = 0;
                        //   retry++;
                    }


                }

            } else {
                System.arraycopy(inb, 0, rcvd, rcvCount, rbyte);
                rcvCount += rbyte;
                byte[] esc = new byte[rcvCount];
                // System.arraycopy(rcvd, 0, esc, 0, rcvCount);
                // 	Log.v("SLEEP5",byteArrayToHex(rcvd) );
                if (rcvd[0] == 0x02) {

                    switch (rcvd[1]) {
                        case 0x46://'F'download response
                            if (rcvCount < 5) return;
                            if ((rcvd[2] & 0x80) == 0x80) {
                                _progress = fwdata.length;
                            } else {
                                _progress = (int) rcvd[2];
                            }
                            _progressDialog.setProgress(_progress + 1);
                            Log.v("DOWNLOAD1", Integer.toString(_progress));
                            byte[] inc = new byte[4];
                            System.arraycopy(rcvd, 0, inc, 0, 4);
                            //	 txtDebug += "rcv2<====("+byteArrayToHex(inc)+")\r\n";
                            //	debugText.setText(txtDebug);

                            if ((rcvd[2] & 0x80) == 0x80) {
                                switch (rcvd[3]) {
                                    case 0x15://NAK
                                        retry++;
                                        if (retry > 2) {
                                            Log.v("NAK", Integer.toString(retry));
                                            downloadComplete(false);
                                            return;
                                        }
                                        break;
                                    case 0x05://NEOT
                                        downloadComplete(false);
                                        return;
                                    case 0x04://EOT
                                        downloadComplete(true);
                                        return;
                                }
                            }

                            if (rcvd[3] == Cmd.ACK) {
                                p_no = ++rcvd[2];
                                retry = 0;
                            } else if (rcvd[3] == Cmd.NAK) {
                                retry++;
                                if (retry > 2) {
                                    Log.v("NAK", Integer.toString(retry));
                                    downloadComplete(false);
                                    return;
                                }
                                p_no = rcvd[2];
                            }


                            int start = p_no * 1024;
                            byte[] data = new byte[1024];

                            if ((fwdata.length - p_no * 1024) < 1024) {

                                System.arraycopy(fwdata, start, data, 0, fwdata.length - p_no * 1024);
                                p_no = (byte) (p_no | 0x80);
                                downFinish = true;
                            } else {
                                Log.v("OVER2", Integer.toString(p_no * 1024));
                                System.arraycopy(fwdata, start, data, 0, 1024);
                            }
                            rcvCount = 0;
                            rcvd = new byte[10];
                            sendPacket(p_no, data, Cmd.VER);
                            return;

                        case 0x45://'E'
                            Log.v("DOWNLOAD", "START");
                            version = rcvd[2];
                            Log.v("DOWNLOAD", "START" + Integer.toString(version));
                            if (rcvd[3] == 0x7E) {
                                // debugText.setVisibility(View.VISIBLE);
                                // webView.setVisibility(View.GONE);
                                MyTaskParams params = new MyTaskParams(rcvd[2], null, null);
                                FwDownLoad myTask = new FwDownLoad((MainViewActivity) activity);
                                myTask.setActivity((MainViewActivity) activity);
                                myTask.execute(params);
                                //  mode=FWD_MODE;
                                //  sendData(0);
                                rcvCount = 0;
                                return;
                            }

                            break;
                        case 0x43://'C'

                            if (rcvd[2] == 0x7E) {
                                //Log.v("SLEEP7",byteArrayToHex(rcvd) );
                                if (rcvd[3] == 0x1F) {
                                    Log.v("SLEEP", "OK");
                                    mChatService.start();
                                    //doDiscovery();
                                    rcvCount = 0;
                                    return;
                                }
                            }

                            break;
                    }
                }
                // txtDebug += "rcv2====>("+Integer.toString(rcvCount)+")" +byteArrayToHex(inb) + "\r\n";

                //debugText.setText(txtDebug);
            }

            if (rcvCount == packetsize + 5) {


                PrepareImage();

            }
        }


    }

    private void downloadComplete(boolean bcomp) {
        if (bcomp) {
            //txtDebug += "download complete!\r\n";
            //debugText.setText(txtDebug);
            //debugText.setVisibility(View.VISIBLE);
            //webView.setVisibility(View.VISIBLE);
            String vstr = "V" + Integer.toString(version).substring(0, 1) + "." + Integer.toString(version).substring(1, 2);
            _progressDialog.setMessage("Firmware Update: SUCCESS!(" + vstr + ")");


        } else {
            //txtDebug += "Update failed!\r\n";
            //debugText.setText(txtDebug);
            _progressDialog.setMessage("Firmware Update: FAILED");
        }
        rcvd = new byte[1029];
        rcvCount = 0;
        retry = 0;
    }

    public File createFileInSDCard(String fileName, String dir)
            throws IOException {
        SDCardRoot = Environment.getExternalStorageDirectory()
                .getAbsolutePath()
                + "/";
        File file = new File(SDCardRoot + dir + File.separator + fileName);
        file.createNewFile();
        return file;
    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    void DeleteRecursive(File fileOrDirectory) {
        if (fileOrDirectory.isDirectory())
            for (File child : fileOrDirectory.listFiles())
                DeleteRecursive(child);

        fileOrDirectory.delete();
    }

    private File createDirectoryAndSaveFile(Bitmap imageToSave, String fileName) {


        File file = new File(fileName);
        if (file.exists())
            file.delete();
        try {
            FileOutputStream out = new FileOutputStream(file);
            imageToSave.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
            Log.v("FILE", "error");
        }
        return file;
    }

    @SuppressLint("NewApi")
    private void PrepareImage() {

        rcvCount = 0;
        byte[] chks = new byte[packetsize + 3];
        byte[] data = new byte[packetsize];
        byte[] cb = new byte[2];
        byte[] indata1 = new byte[10];
        byte[] indata2 = new byte[10];
        System.arraycopy(rcvd, 0, indata1, 0, 10);
        System.arraycopy(rcvd, 1019, indata2, 0, 10);
        // txtDebug += "IN DATA <====" + byteArrayToHex(indata1)+"..."+ byteArrayToHex(indata2) + "\r\n";
        //Log.d("Packet",byteArrayToHex(indata1));
        cb[0] = rcvd[2];
        cb[1] = 0x00;
        txtDebug += byteArrayToHex(cb) + " ";
        debugText.setText(txtDebug);
        System.arraycopy(rcvd, 1, chks, 0, packetsize + 3);


        byte crc = CalculateChecksum(chks);

        cb[0] = rcvd[2];//rcvd[packetsize + 4];
        cb[1] = rcvd[3];//crc;
        if (rcvd[packetsize + 4] + crc == 256 || rcvd[packetsize + 4] + crc == 0 || rcvd[packetsize + 4] == crc) {
            if ((rcvd[2] & 0x80) == 0x80) {
                sendACK(5, rcvd[2]);
                rcnt = rcvd[2];
                //Log.v("SEND ACK LAST",byteArrayToHex(cb) );
            } else {
                sendACK(1, rcvd[2]);
                rcnt = rcvd[2];
                // Log.v("SEND ACK",byteArrayToHex(cb) );
            }


        } else {

            if (retry == 2) {
                Log.e("CRC", "CRC OVER");
                sendACK(1, rcnt);

                txtDebug += "CRC OVER====>" + byteArrayToHex(cb) + "\r\n";
                debugText.setText(txtDebug);
            } else {
                rcvd = new byte[packetsize + 5];
                rcvCount = 0;

                Log.e("CRC", byteArrayToHex(cb));
                txtDebug += "CRC====>" + byteArrayToHex(cb) + "\r\n";
                debugText.setText(txtDebug);
                sendACK(1, rcnt);//sendACK(2, rcnt);
                Log.d("NAK", "2");
                // retry++;
                return;
            }
        }


        System.arraycopy(rcvd, 3, data, 0, packetsize);

        retry = 0;

        try {
            //txtDebug+="===1";
            // debugText.setText(txtDebug);
            imgos.write(data);

            //Log.v("ADD data","ADD" );
        } catch (IOException e) {

            // TODO Auto-generated catch block
            //e.printStackTrace();

            txtDebug += "WRITE ERROR====>\r\n";
            debugText.setText(txtDebug);
        }

        if ((rcvd[2] & 0x80) == 0x80) {

            Log.v("BATT3", "EOT");
            String[] path = new String[2];
            File file = null;
            path[0] = Environment.getExternalStorageDirectory().toString() + "/.pqdic1.jpg";
            path[1] = Environment.getExternalStorageDirectory().toString() + "/.pqdic2.jpg";

            	/*
    				try {
    					 FileOutputStream fos = new FileOutputStream(Environment.getExternalStorageDirectory().toString()+"/pqdic.jpg");
  					fos.write(imgos.toByteArray());
  					fos.close();
  				} catch (IOException e) {
  					// TODO Auto-generated catch block
  					Log.v("file1","error");
  					e.printStackTrace();
  				}*/
            Bitmap bmp = byteArrayToBitmap(imgos.toByteArray());


            file = createDirectoryAndSaveFile(bmp, path[count % 2]);


            _imageUri = Uri.fromFile(file);

            loadData();
            imgos = new ByteArrayOutputStream();
            rcvd = new byte[packetsize + 5];


            txtDebug = "";
            count++;
        } else {
            if (rcvd[2] == 0x00) {
                //////////

                short bat_level = rcvd[packetsize + 3];

                if (wordmode == 0) {
                    btitle = "[DicPen]" + selLang[slang] + "->" + selLang[tlang + 1] + "(WORD)";

                } else if (wordmode == 1) {
                    btitle = "[DicPen]" + selLang[slang] + "->" + selLang[tlang + 1] + "(SEN)";
                }

                Log.v("BATT", Integer.toString(bat_level));
                //  title=(String) btitle+"BAT_"+Integer.toString(bat_level)+"%";
                if (bat_level >= 40) {

                    batTitle = "배터리 잔량 :" + Integer.toString(100) + "%";
                    getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0000ff")));
                } else if (bat_level == 39) {
                    batTitle = "배터리 잔량 :" + Integer.toString(90) + "%";
                    getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0000ff")));
                } else if (bat_level == 38)

                {
                    batTitle = "배터리 잔량 :" + Integer.toString(80) + "%";
                    getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0000ff")));
                } else if (bat_level == 37) {
                    batTitle = "배터리 잔량 :" + Integer.toString(70) + "%";
                    getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0000ff")));
                } else if (bat_level == 36) {
                    batTitle = "배터리 잔량 :" + Integer.toString(60) + "%";
                    getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0000ff")));
                } else if (bat_level == 35) {
                    batTitle = "배터리 잔량 :" + Integer.toString(40) + "%";
                    getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#0000ff")));
                } else if (bat_level == 34) {
                    batTitle = "배터리 잔량 :" + Integer.toString(20) + "%";
                    getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#ff0000")));
                } else {
                    batTitle = "배터리 잔량 :" + Integer.toString(10) + "%";
                    getActionBar().setBackgroundDrawable(new ColorDrawable(Color.parseColor("#ff0000")));
                }
                Log.e("여길봐라", "배터리 잔량 부분 들어오나 " + batTitle);
                //setTitle(title);
                //title=(String) btitle+"BAT_"+Short.toString(bat_level);
                setTitle(Html.fromHtml("<small>" + btitle + "</small>"));
                if (bat_level <= 34)
                    showDialog(DIALOG_LOW_BATT);
                String[] baseText = stateText.getText().toString().split(" 배터리");
                stateText.setText(baseText[0] + " " + batTitle);
            } else {
                //Log.v("BATT2",Integer.toString(rcvd[2]));
            }
            /////////
        }

        rcvd = new byte[packetsize + 5];
        rcvCount = 0;


    }

    public Bitmap byteArrayToBitmap(byte[] $byteArray) {
        Bitmap bitmap = BitmapFactory.decodeByteArray($byteArray, 0, $byteArray.length);
        return bitmap;
    }

    private byte CalculateChecksum(byte[] byteToCalculate) {

        byte checksum = 0;
        for (byte chData : byteToCalculate) {
            checksum += chData;
        }
        // checksum &= 0xff;
        return checksum;
    }

    private void sendPacket(byte p_no, byte[] data, byte ver) {
        byte[] out = new byte[5];
        byte[] chks = new byte[1024 + 3];

        byte[] cb = new byte[2];
        byte[] header = {0x02, 0x42};


        byte[] packet = new byte[1029];
        System.arraycopy(header, 0, packet, 0, 2);

        packet[2] = p_no;
        //System.arraycopy(p_no, 0, packet, 2, 1);
        System.arraycopy(data, 0, packet, 3, 1024);
        if ((p_no & 0x80) == 0x80) {
            ver = CalculateChecksum(fwdata);
        }

        packet[1027] = ver;
        System.arraycopy(packet, 1, chks, 0, 1024 + 3);

        byte crc = CalculateChecksum(chks);
        cb[0] = p_no;
        cb[1] = crc;
        packet[1028] = crc;
        Log.v("PACKET3", byteArrayToHex(cb));
        //  Log.v("PACKET4",byteArrayToHex(packet));
        mChatService.write(packet);
        System.arraycopy(packet, 0, out, 0, 5);
        txtDebug += "send====>(" + byteArrayToHex(out) + ")\r\n";
        debugText.setText(txtDebug);
    }

    private void sendACK(int step, byte cnt) {
        byte[] header1 = {Cmd.STX, 0x43, cnt, Cmd.ACK};
        byte[] header2 = {Cmd.STX, 0x43, cnt, Cmd.NAK};
        byte[] header3 = {Cmd.STX, Cmd.EOT};
        byte br = (byte) (cnt | ((byte) bright << 5));
        byte[] header5 = {Cmd.STX, 0x43, br, Cmd.ACK};
        byte[] header6 = {'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U', 'U'};
        String hex = "ACK";

        if (step == 0) {
            hex = "0====>EOT \r\n";
            mChatService.write(header3);
            //txtDebug+="==>"+byteArrayToHex(header3) + "\r\n";
        } else if (step == 1) {
            hex = "1====>ACK \r\n";
            mChatService.write(header1);
            //+="==>"+byteArrayToHex(header1) + "\r\n";
        } else if (step == 2) {
            hex = "2====> NAK\r\n";
            mChatService.write(header2);
            txtDebug += "==>" + byteArrayToHex(header2) + "\r\n";
            debugText.setText(txtDebug);
        } else if (step == 3) {
            hex = "3====>" + "EOT" + "\r\n";
            mChatService.write(header3);
            //  txtDebug+=hex;
        } else if (step == 5) {
            hex = "5====>" + "ACK" + "\r\n";
            mChatService.write(header5);
            // txtDebug+=hex;
        } else if (step == 6) {
            hex = "6====>" + "ACK" + "\r\n";
            mChatService.write(header6);
            // txtDebug+=hex;
        }
        Log.v("ACK", Integer.toString(cnt) + Integer.toString(step));
        //  debugText.setText(txtDebug);

    }

    @Override
    public void onStart() {
        super.onStart();
        Log.e(TAG, "++ ON START ++");

        // If BT is not on, request that it be enabled.
        // setupChat() will then be called during onActivityResult
        if (!mBluetoothAdapter.isEnabled()) {
            Intent enableIntent = new Intent(
                    BluetoothAdapter.ACTION_REQUEST_ENABLE);
            startActivityForResult(enableIntent, REQUEST_ENABLE_BT);
            // Otherwise, setup the chat session
        } else {
            if (mChatService == null)
                setupViews();
        }
    }

    @Override
    public void onBackPressed() {
        // super.onBackPressed();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Really Exit?");
        builder.setMessage("Are you sure you want to exit?");
        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
                return;
            }
        });
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();

                if (mBluetoothAdapter != null) {
                    mBluetoothAdapter.cancelDiscovery();
                }

                // Unregister broadcast listeners
                unregisterCallReceiver();
                // Stop the Bluetooth chat services
                if (mChatService != null)
                    mChatService.stop();


                if (_imageLoadTask != null) {
                    _imageLoadTask.cancel(true);
                }


                while (mBluetoothAdapter.isEnabled()) {
                    mBluetoothAdapter.disable();
                }

                //	mBluetoothAdapter.enable();

                Log.v(MainViewActivity.TAG, "onBackPressed()");
                finish();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();


    }

    private void unregisterCallReceiver() {
        if (mIsReceiverRegistered) {
            this.unregisterReceiver(mReceiver);
            mIsReceiverRegistered = false;
        }
    }

    private void registerCallReceiver() {
        if (!mIsReceiverRegistered) {
            IntentFilter filter = new IntentFilter(BluetoothDevice.ACTION_FOUND);
            this.registerReceiver(mReceiver, filter);

            // Register for broadcasts when discovery has finished
            filter = new IntentFilter(BluetoothAdapter.ACTION_DISCOVERY_FINISHED);
            this.registerReceiver(mReceiver, filter);

            mIsReceiverRegistered = true;
        }
    }

    public void onDestroy() {

        if (mBluetoothAdapter != null) {
            mBluetoothAdapter.cancelDiscovery();
        }

        // Unregister broadcast listeners
        unregisterCallReceiver();
        // Stop the Bluetooth chat services
        if (mChatService != null) {
            mChatService.stop();
        }


        if (_imageLoadTask != null) {
            _imageLoadTask.cancel(true);
        }

        Log.v(MainViewActivity.TAG, "onDestroy()");
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    public Object onRetainNonConfigurationInstance() {
        Log.v(MainViewActivity.TAG, "onRetainNonConfigurationInstance()");
        return this._image;
    }

    @Override
    protected void onSaveInstanceState(final Bundle outState) {
        Log.v(MainViewActivity.TAG, "onSaveInstanceState()");
        super.onSaveInstanceState(outState);

        outState.putParcelable(MainViewActivity.KEY_IMAGE_URI, _imageUri);
        outState.putSerializable(MainViewActivity.KEY_IMAGE_SOURCE, _imageSource);
    }

    @SuppressWarnings("deprecation")
    @Override
    protected Dialog onCreateDialog(final int dialogId) {
        switch (dialogId) {
            case NOT_PAIRING:
			/*if (mBluetoothAdapter != null) {
    			mBluetoothAdapter.cancelDiscovery();
    		}*/
                return new AlertDialog.Builder(this)
                        .setCancelable(false)
                        .setTitle("Not found paired pen!")
                        .setMessage("Check the  pairing state")
                        .setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                dialog.dismiss();
                                connectcount = 0;
                                doDiscovery();
                            }
                        })

                        .setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                dialog.dismiss();
                                dialog.cancel();

                                if (mBluetoothAdapter != null) {
                                    mBluetoothAdapter.cancelDiscovery();
                                }

                                // Unregister broadcast listeners
                                unregisterCallReceiver();
                                // Stop the Bluetooth chat services
                                if (mChatService != null)
                                    mChatService.stop();


                                if (_imageLoadTask != null) {
                                    _imageLoadTask.cancel(true);
                                }


                                while (mBluetoothAdapter.isEnabled()) {
                                    mBluetoothAdapter.disable();
                                }

                                finish();
                            }

                        }).create();
            case NOT_CONNECT:
			/*if (mBluetoothAdapter != null) {
    			mBluetoothAdapter.cancelDiscovery();
    		}*/
                return new AlertDialog.Builder(this)
                        .setCancelable(false)
                        .setTitle("Unable connect!")
                        .setMessage("Check the pen state, or pairing state")
                        .setPositiveButton("Retry", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                dialog.dismiss();
                                connectcount = 0;
                                doDiscovery();
                            }
                        })

                        .setNegativeButton("Exit", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {

                                dialog.dismiss();
                                dialog.cancel();

                                if (mBluetoothAdapter != null) {
                                    mBluetoothAdapter.cancelDiscovery();
                                }

                                // Unregister broadcast listeners
                                unregisterCallReceiver();
                                // Stop the Bluetooth chat services
                                if (mChatService != null)
                                    mChatService.stop();


                                if (_imageLoadTask != null) {
                                    _imageLoadTask.cancel(true);
                                }


                                while (mBluetoothAdapter.isEnabled()) {
                                    mBluetoothAdapter.disable();
                                }

                                finish();
                            }

                        }).create();

            case DIALOG_LOW_BATT:
                return new AlertDialog.Builder(this)
                        .setCancelable(false)
                        .setTitle("Warning!")
                        .setMessage("Pen Battery low, Before use, the battery must be charged")
                        .setPositiveButton(getString(R.string.button_close),
                                new DialogInterface.OnClickListener() {
                                    public void onClick(final DialogInterface dialog, final int id) {
                                        dialog.cancel();
                                    }
                                }).create();

            case DIALOG_FW_DOWNLOAD_FAIL:
                return new AlertDialog.Builder(this)
                        .setCancelable(false)
                        .setTitle("Firmware Update")
                        .setMessage("This version latest. need not update!")
                        .setPositiveButton(getString(R.string.button_close),
                                new DialogInterface.OnClickListener() {
                                    public void onClick(final DialogInterface dialog, final int id) {
                                        dialog.cancel();
                                    }
                                }).create();

            case DIALOG_ERROR_LOADING_IMAGE:
                return new AlertDialog.Builder(this)
                        .setCancelable(false)
                        .setTitle(getString(R.string.dialog_error))
                        .setMessage(getString(R.string.error_loading_image))
                        .setPositiveButton(getString(R.string.button_close),
                                new DialogInterface.OnClickListener() {
                                    public void onClick(final DialogInterface dialog, final int id) {
                                        dialog.cancel();
                                    }
                                }).create();

            case DIALOG_FW_DOWNLOAD:
                _progressDialog = new ProgressDialog(this);
                _progressDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                _progressDialog.setMax(fwdata.length / 1024);
                _progressDialog.setMessage("Firmware Update...");
                _progressDialog.setButton(getString(R.string.button_close),
                        new DialogInterface.OnClickListener() {
                            public void onClick(final DialogInterface dialog, final int id) {
                                _progressDialog.setMessage("Firmware Update:");
                                rcvd = new byte[packetsize + 5];
                                dialog.cancel();
                            }
                        });
                return _progressDialog;


            default:
                return super.onCreateDialog(dialogId);
        }
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        switch (requestCode) {
            case PREFERENCE_SET:
                if (resultCode == Activity.RESULT_OK || resultCode == Activity.RESULT_CANCELED) {
                    ArrayList<String> values = new ArrayList<String>();
                    SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("MyPref", 0);

                    int sIndex = sharedPref.getInt("src", Const.SRC_LANG_0_English);
                    int tIndex = sharedPref.getInt("tar", Const.DEST_LANG_3_Korean);
                    wordmode = sharedPref.getInt("mode", 0);
                    bright = sharedPref.getInt("brmode", 0);
                    //usrdb = sharedPref.getInt("usr", 0);
                    dicName = sharedPref.getString("dicName", Const.DIC_NAVER);
                    //byte[] header1 = { STX, 0x44, (byte) bright, ETX };
                    //mChatService.write(header1);
                    Log.v("PRESET", Integer.toString(sIndex) + "=" + Integer.toString(wordmode));
                    _separator = DEFAULT__SEPARATOR;

                    getPreferencesData();
                }
                break;
            case REQUEST_CODE_PICK_IMAGE:
                if (resultCode == Activity.RESULT_OK) {
                    _imageUri = data.getParcelableExtra(MainViewActivity.KEY_IMAGE_URI);
                }
                break;
            case REQUEST_CONNECT_DEVICE:
                // When DeviceListActivity returns with a device to connect
                if (resultCode == Activity.RESULT_OK) {
                    connectDevice(data, null);
                }
                break;
            case REQUEST_ENABLE_BT:
                // When the request to enable Bluetooth returns
                if (resultCode == Activity.RESULT_OK) {
                    // Bluetooth is now enabled, so set up a chat session
                    setupViews();

                } else {
                    // User did not enable Bluetooth or an error occurred
                    Log.d(TAG, "BT not enabled");
                    Toast.makeText(this, R.string.bt_not_enabled_leaving,
                            Toast.LENGTH_SHORT).show();
                    finish();
                }
            case REQUEST_CODE_RECOGNITION_FINISHED:

                break;
            default:

                super.onActivityResult(requestCode, resultCode, data);
        }
    }

    private boolean initialize(final Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            _imageUri = savedInstanceState.getParcelable(MainViewActivity.KEY_IMAGE_URI);
            _image = (Bitmap) getLastNonConfigurationInstance();
            _imageSource = (ImageSource) savedInstanceState.getSerializable(MainViewActivity.KEY_IMAGE_SOURCE);

            if (_image != null && _imageUri == null) {
                return false;
            }
        }

        return true;
    }


    private void setupViews() {
        stateText = (TextView) findViewById(R.id.status);
        debugText = (TextView) findViewById(R.id.outtxt);
        debugText.setMovementMethod(ScrollingMovementMethod.getInstance());
        debugText.setScrollBarStyle((int) 0x03000000);
        debugText.setVerticalScrollBarEnabled(true);
        debugText.setTextColor(0xFFFFFF00);

        debugText.setVisibility(View.GONE);

        _imagePreview = (ImageView) findViewById(R.id.image_preview);

        TypedValue tv = new TypedValue();
        int actionBarHeight = 0;
        if (getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
            actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, getResources().getDisplayMetrics());
        }
        if (getResources().getConfiguration().keyboard == android.content.res.Configuration.KEYBOARD_NOKEYS) {
            actionBarHeight *= 2;
        }
        webView = (WebView) findViewById(R.id.webView1);
        webView.setLayoutParams(new LinearLayout.LayoutParams(getResources().getDisplayMetrics().widthPixels, (getResources().getDisplayMetrics().heightPixels) - ((actionBarHeight) + 240)));


        //_imagePreview.setVisibility(View.GONE);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        webView.getSettings().setSupportMultipleWindows(true);
        webView.getSettings().setDomStorageEnabled(true);

        webView.setWebViewClient(new WebViewClient() {
                                     @Override
                                     public boolean shouldOverrideUrlLoading(WebView view, String url) {
                                         Log.d(TAG, "shouldOverrideUrlLoading : " + url);
                                         view.loadUrl(url);
                                         return true;

                                     }

                                 }
        );

        // Initialize the BluetoothChatService to perform bluetooth connections
        mChatService = new BluetoothService(this, mHandler);


        getPreferencesData();
        doDiscovery();
    }

    void loadData() {
        if (this._imageUri != null) {

            loadImage();
            Log.v("Load Image", "Load");
        } else {
            Log.v("Load Image", "Not Load");
        }

        doTempWakeLock();
    }

    private void loadImage() {

        _imagePreview.setImageBitmap(null);
        final Uri uri = this._imageUri;
        if (this._imageLoadTask != null) {
            this._imageLoadTask.cancel(true);
        }

        this._imageLoadTask = new AsyncTask<Void, Void, Bitmap>() {
            @Override
            protected Bitmap doInBackground(final Void... params) {
                Bitmap img = getImage(uri);
                inspectFromBitmap(img);
                return img;
            }

            @Override
            protected void onPostExecute(final Bitmap result) {
                dispatchImageLoaded(result);
            }
        };
        this._imageLoadTask.execute();
    }

    public class ImgMargin {
        public int imgWidth;
        public int leftMargin;
        public int rightMargin;
    }

    private ImgMargin margin = new ImgMargin();

    public Bitmap getImage(final Uri imageUri) {
        Log.v(TAG, "getImage(" + imageUri + ")");
        Bitmap bitmap = null;
        try {
            bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), imageUri);
            margin.imgWidth = bitmap.getWidth();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        bitmap = DicPenUtil.processBitmap(bitmap, margin);

        return bitmap;
    }

    void dispatchImageLoaded(final Bitmap image) {
        Log.v(MainViewActivity.TAG, "dispatchImageLoaded()");

        if (image == null) {
            showDialog(MainViewActivity.DIALOG_ERROR_LOADING_IMAGE);
        } else {

            _imagePreview.setImageBitmap(image);
        }

        searchDic(image);

    }


    public int convertByteToInt(byte[] b) {
        int value = 0;
        for (int i = 0; i < b.length; i++)
            value = (value << 8) | b[i];
        return value;
    }

//    private void deleteUsage() {
//        String deleteCmd = "pm clear com.woon.DicPen";
//        Runtime runtime = Runtime.getRuntime();
//        try {
//            runtime.exec(deleteCmd);
//        } catch (IOException e) {
//            e.printStackTrace();
//        }
//        SharedPreferences sharedPref = getApplicationContext().getSharedPreferences("MyPref", 0);
//        wordmode = sharedPref.getInt("mode", 0);
//        slang = sharedPref.getInt("src", Const.AUTO_LANG);
//        tlang = sharedPref.getInt("tar", Const.DEST_LANG_3_Korean);
//        //usrdb = sharedPref.getInt("usr", 0);
//        dicName = sharedPref.getString("dicName", Const.DIC_GOOGLE);
//        bright = sharedPref.getInt("brmode", 1);
//        SharedPreferences.Editor editor = sharedPref.edit();
//        editor.putInt("src", slang);
//        editor.putInt("tar", tlang);
//        //editor.putInt("usr", usrdb);
//        editor.putString("dicName", dicName);
//        editor.putInt("mode", wordmode);
//        editor.putInt("brmode", bright);
//
//        //jasonString=json.toString();
//        //editor.putString("userlink", linkdb);
//        editor.commit();
//    }

    private void LoadDic(String encqry) {
        Log.v("LoadDic", Integer.toString(slang) + "=" + Integer.toString(tlang) + "=" + encqry);

        bUrl = DicUrl.getUrl(mPref, slang, tlang, dicName, encqry);

        webView.loadUrl(bUrl);

        Log.d("LoadDic-URL:", bUrl);
    }

    /**
     * Enable "Recognize *" buttons. You should call enabledButtons() for each disableButtons() call to enable
     * buttons.
     */
    private void enableRecognitionButtons() {
        _disableButtonsCounter = Math.max(_disableButtonsCounter - 1, 0);
        if (_disableButtonsCounter == 0) {
            setEnabledRecognitionButtons(true);
        }
    }

    /**
     * Disable "Recognize *" buttons. You should call enabledButtons() for each disableButtons() call to
     * enable buttons.
     */
    private void disableRecognitionButtons() {
        if (_disableButtonsCounter == 0) {
            setEnabledRecognitionButtons(false);
        }
        ++_disableButtonsCounter;
    }

    /**
     * <p>
     * For internal usage. Change "enabled" state of "Recognize *" buttons.
     * </p>
     * <p>
     * Use enableRecognitionButtons() and disableRecognitionButtons() instead.
     * </p>
     *
     * @param enabled New "enabled" state.
     */
    private void setEnabledRecognitionButtons(final boolean enabled) {
        if (_recognizeTextButton != null) {
            _recognizeTextButton.setEnabled(enabled);
        }
        if (_recognizeBcrButton != null) {
            _recognizeBcrButton.setEnabled(enabled);
        }
        if (_recognizeBarcodeButton != null) {
            _recognizeBarcodeButton.setEnabled(enabled);
        }
    }

    private void ensureDiscoverable() {
        if (D)
            Log.d(TAG, "ensure discoverable");
        if (mBluetoothAdapter.getScanMode() != BluetoothAdapter.SCAN_MODE_CONNECTABLE_DISCOVERABLE) {
            Intent discoverableIntent = new Intent(
                    BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE);
            discoverableIntent.putExtra(
                    BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300);
            startActivity(discoverableIntent);
        }
    }

    private void sendMessage(String message) {
        // Check that we're actually connected before trying anything
        if (mChatService.getState() != BluetoothService.STATE_CONNECTED) {
            Toast.makeText(this, R.string.not_connected, Toast.LENGTH_SHORT)
                    .show();
            return;
        }

        // Check that there's actually something to send
        if (message.length() > 0) {
            // Get the message bytes and tell the BluetoothChatService to write
            byte[] send = message.getBytes();
            mChatService.write(send);

            // Reset out string buffer to zero and clear the edit text field

        }
    }

    private final void setStatus(int resId) {
        stateText.setText(resId);
    }

    private final void setStatus(CharSequence subTitle) {
        stateText.setText(subTitle);
    }

    // The Handler that gets information back from the BluetoothChatService
    private final Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case FW_UPDATE:
                    Log.i(TAG, "FW_UPDATE");

				/*int total = msg.getData().getInt("total");
				Log.v("UPDATE", Integer.toString(total));
				_progressDialog.setProgress(total);*/

                    break;
                case MESSAGE_UNLOCK:
                    Log.i(TAG, "MESSAGE_UNLOCK");
                    window.addFlags(LayoutParams.FLAG_DISMISS_KEYGUARD);
                    window.addFlags(LayoutParams.FLAG_SHOW_WHEN_LOCKED);
                    window.addFlags(LayoutParams.FLAG_TURN_SCREEN_ON);

                    break;
                case MESSAGE_BT_CONNECT:
                    Log.i(TAG, "MESSAGE_BT_CONNECT");
                    break;
                case MESSAGE_DISCOVERY_FINISHED:
                    Log.i(TAG, "MESSAGE_DISCOVERY_FINISHED");
                    if (mChatService.getState() != BluetoothService.STATE_CONNECTED && mChatService.getState() != BluetoothService.STATE_CONNECTING)
                        doDiscovery();
                    break;
                case MESSAGE_STATE_CHANGE:
                    Log.i(TAG, "MESSAGE_STATE_CHANGE: " + msg.arg1);
                    switch (msg.arg1) {
                        case BluetoothService.STATE_CONNECTED:
                            connectcount = 0;
                            setStatus(getString(R.string.title_connected_to,
                                    mConnectedDeviceName));

                            //byte[] header1 = { STX, 0x44, (byte) bright, ETX };
                            //mChatService.write(header1);
                            break;
                        case BluetoothService.STATE_CONNECTING:
                            setStatus(R.string.title_connecting);
                            break;
                        case BluetoothService.STATE_LISTEN:
                        case BluetoothService.STATE_BLUETOOTH_OFF:
                            setStatus(R.string.title_not_bluetooth);
                            break;
                        case BluetoothService.STATE_NONE:
                            setStatus(R.string.title_not_connected);

                            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                            break;
                    }
                    break;
                case MESSAGE_WRITE:
                    Log.i(TAG, "MESSAGE_WRITE");
                    byte[] writeBuf = (byte[]) msg.obj;
                    // construct a string from the buffer
                    String writeMessage = new String(writeBuf);

                    break;
                case MESSAGE_READ:
                    //Log.i(TAG, "MESSAGE_READ");
                    byte[] readBuf = (byte[]) msg.obj;


				/*String readMessage = new String(readBuf, 0, msg.arg1);

				txtDebug+=readMessage;
				debugText.setText(txtDebug);*/
                    try {
                        processPacket(readBuf, msg.arg1);
                        msg = null;
                    } catch (UnsupportedEncodingException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                    break;
                case MESSAGE_DEVICE_NAME:
                    Log.i(TAG, "MESSAGE_DEVICE_NAME");
                    // save the connected device's name
                    mConnectedDeviceName = msg.getData().getString(DEVICE_NAME);
                    Toast.makeText(getApplicationContext(),
                            "Connected to " + mConnectedDeviceName,
                            Toast.LENGTH_SHORT).show();
                    break;
                case MESSAGE_TOAST:
                    Log.i(TAG, "MESSAGE_TOAST");
                    Toast.makeText(getApplicationContext(),
                            msg.getData().getString(TOAST), Toast.LENGTH_SHORT)
                            .show();
                    break;
                case MESSAGE_CONNECT_FAIL:
                    Log.i(TAG, "MESSAGE_CONNECT_FAIL");
                    //Toast.makeText(getApplicationContext(),
                    //		"Unable connect", Toast.LENGTH_SHORT)
                    //		.show();
                    connectcount++;
                    doDiscovery();
                    break;
            }
        }
    };

    private void connectDevice(Intent data, String addr) {
        // Get the device MAC address
        String address = null;
        if (addr == null) {
            address = data.getExtras().getString(
                    DeviceListActivity.EXTRA_DEVICE_ADDRESS);

        } else address = addr;
        // Get the BluetoothDevice object
        BluetoothDevice device = mBluetoothAdapter.getRemoteDevice(address);
        // Attempt to connect to the device
        mChatService.connect(device);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.option_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent serverIntent = null;
        switch (item.getItemId()) {
	/*	case R.id.connect_scan:
			// Launch the DeviceListActivity to see devices and do scan
			serverIntent = new Intent(this, DeviceListActivity.class);
			startActivityForResult(serverIntent, REQUEST_CONNECT_DEVICE);
			break;*/
            case R.id.language:

                doTempWakeLock();

                final Intent intent = new Intent(this, UserPreference.class);

                startActivityForResult(intent, MainViewActivity.PREFERENCE_SET);

                break;
        }
        return false;
    }

}
