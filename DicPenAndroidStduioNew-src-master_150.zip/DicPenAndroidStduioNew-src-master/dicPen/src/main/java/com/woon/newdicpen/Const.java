package com.woon.newdicpen;

/**
 * Created by dulee on 2017-05-14.
 */

public class Const {
    public static final int AUTO_LANG = 0;

    public static final int SRC_LANG_0_English = 1;
    public static final int SRC_LANG_4_French = 2;
    public static final int SRC_LANG_5_German = 3;
    public static final int SRC_LANG_6_Spanish = 4;
//    public static final int SRC_LANG_3_Korean = 5;
//    public static final int SRC_LANG_2_Chinese = 6;
//    public static final int SRC_LANG_1_Japanese = 7;

    public static final int DEST_LANG_0_English = 0;
    public static final int DEST_LANG_4_French = 1;
    public static final int DEST_LANG_5_German = 2;
    public static final int DEST_LANG_6_Spanish = 3;
    public static final int DEST_LANG_3_Korean = 4;
    public static final int DEST_LANG_2_Chinese = 5;
    public static final int DEST_LANG_1_Japanese = 6;

    public static final int BR_MODE_0_LOW = 0;
    public static final int BR_MODE_1_MEDIUM = 1;// 1
    public static final int BR_MODE_2_HIGH = 2;

    public static final int TRANS_MODE_0_WORD = 0;
    public static final int TRANS_MODE_1_SENTENCE = 1;

    public static final String DIC_GOOGLE = "google";
    public static final String DIC_NAVER = "naver";
    public static final String DIC_YAHOO = "yahoo";
    public static final String DIC_ICIBA = "iciba";


}
